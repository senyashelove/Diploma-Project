import React from 'react';
import { Box, Table, TableBody, TableCell, TableHead, TableRow, CircularProgress, Button } from '@mui/material';
import { userAPI } from '../services/UsrService';

const UserList = () => {
  const { data: users = [], isLoading, refetch } = userAPI.useGetUsersQuery();
  const [deleteUser] = userAPI.useDeleteUserMutation();

  const handleDeleteUser = async (id, role) => {
    if (role === 'ADMIN') {
      alert('Невозможно удалить пользователя с ролью ADMIN.');
      return;
    }
    await deleteUser(id).unwrap();
    refetch();
  };

  return (
    <Box>
      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Имя</TableCell>
              <TableCell>Фамилия</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Роль</TableCell>
              <TableCell>Действия</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.id}</TableCell>
                <TableCell>{user.name}</TableCell>
                <TableCell>{user.surname}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.role}</TableCell>
                <TableCell>
                  <Button
                    color="error"
                    onClick={() => handleDeleteUser(user.id, user.role)}
                  >
                    Удалить
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </Box>
  );
};

export default UserList;
