import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Grid, Typography, Container } from '@mui/material';
import ApartmentItem from './Apartmentitem';

const FavoritesList = () => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const fetchFavorites = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;

        const headers = { Authorization: `${token}` };

        const response = await axios.get('https://localhost:5000/favorites', { headers });

        setFavorites(response.data);
      } catch (error) {
        console.error('Ошибка при получении избранных квартир:', error);
      }
    };

    fetchFavorites();
  }, []);

  return (
    <Container sx={{ mt: 4 }}>
      <Typography variant="h4" fontWeight={700} mb={4} color="primary">
        Избранные квартиры
      </Typography>

      {favorites.length === 0 ? (
        <Typography variant="body1">У вас пока нет избранных квартир.</Typography>
      ) : (
        <Grid container spacing={3}>
          {favorites.map((fav) => (
            <Grid item xs={12} sm={6} md={4} key={fav.id}>
              <ApartmentItem apartments={fav.apartment} />
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
};

export default FavoritesList;
