import React from 'react';
import { 
  Typography, 
  Box, 
  Card, 
  CardContent, 
  CardMedia, 
  Chip,
  Divider,
  Button
} from '@mui/material';
import { Link } from 'react-router-dom';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import ApartmentIcon from '@mui/icons-material/Apartment';
import { styled } from '@mui/material/styles';

// Custom styled components
const StyledCard = styled(Card)(({ theme }) => ({
  width: '500px',
  height: 'auto',
  borderRadius: '16px',
  overflow: 'hidden',
  boxShadow: '0 8px 40px rgba(0, 0, 0, 0.12)',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-8px)',
    boxShadow: '0 16px 70px rgba(0, 0, 0, 0.2)',
  },
}));

const ImageOverlay = styled(Box)({
  position: 'absolute',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  background: 'linear-gradient(to top, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0) 35%)',
  zIndex: 1,
});

const StyledChip = styled(Chip)({
  position: 'absolute',
  top: 16,
  right: 16,
  fontWeight: 600,
  backgroundColor: 'rgba(255, 255, 255, 0.85)',
  backdropFilter: 'blur(5px)',
  zIndex: 2,
});

const HouseItem = ({ house }) => {
  // Fallback for missing data
  const houseName = house?.name || "Прекрасный дом";
  const location = house?.address || "Премиум локация"; // Используем поле address из модели Houses

  // Получаем квартиры из объекта дома
  const apartments = house?.apartments || [];

  // Подсчет количества свободных квартир для текущего дома
  const availableApartments = apartments.filter(apt => !apt.isSold).length;
  
  return (
    <StyledCard>
      <Box sx={{ position: 'relative' }}>
        <CardMedia
          component="img"
          height="300"
          image={house?.image || 'https://source.unsplash.com/random/?house,modern'}
          alt={houseName}
          sx={{ 
            objectFit: 'cover',
            transition: 'transform 0.5s ease',
            '&:hover': {
              transform: 'scale(1.05)'
            }
          }}
        />
        <ImageOverlay />
        <StyledChip label="Особое предложение" size="small" />
      </Box>
      
      <CardContent sx={{ p: 3 }}>
        <Typography 
          variant="h5" 
          component="div"
          sx={{ 
            fontWeight: 800, 
            mb: 1,
            fontSize: '1.5rem',
            letterSpacing: '-0.02em'
          }}
        >
          {houseName}
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, color: 'text.secondary' }}>
          <LocationOnOutlinedIcon sx={{ fontSize: 18, mr: 0.5 }} />
          <Typography variant="body2" sx={{ opacity: 0.85 }}>
            {location}
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, color: 'text.secondary' }}>
          <ApartmentIcon sx={{ fontSize: 18, mr: 0.5 }} />
          <Typography variant="body2" sx={{ opacity: 0.85 }}>
            Доступно квартир: {availableApartments}
          </Typography>
        </Box>
        
        <Divider sx={{ my: 2 }} light />
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="body2" color="text.secondary">
            Премиум недвижимость
          </Typography>
          <Link to={`/houses/${house?.id}/apartments`} style={{ textDecoration: 'none' }}>
            <Button 
              variant="contained" 
              color="primary"
              sx={{ 
                borderRadius: '8px',
                textTransform: 'none',
                fontWeight: 600,
                boxShadow: '0 4px 14px rgba(0, 0, 0, 0.1)',
                color: 'white',
              }}
            >
              Посмотреть квартиры
            </Button>
          </Link>
        </Box>
      </CardContent>
    </StyledCard>
  );
};

export default HouseItem;