import React, { useContext, useState } from 'react';
import { houseAPI } from '../services/houseService';
import ApartmentItem from '../components/Apartmentitem.jsx';
import { Grid, MenuItem, FormControl, Select, InputLabel, Box, Slider, Typography, Paper, Button, Container, alpha, CircularProgress, Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import { Context } from '../index';
import { useParams } from 'react-router-dom';
import { AttachMoney, ExpandMore, Home, SquareFoot } from '@mui/icons-material';

const ApartmentContainer = () => {
  const { houseId } = useParams();
  const { data, error, isLoading } = houseAPI.useGetApartmentsByHouseIdQuery(houseId);
  const { store } = useContext(Context);

  const [roomsFilter, setRoomsFilter] = useState('');
  const [floorFilter, setFloorFilter] = useState('1');
  const [areaRange, setAreaRange] = useState([0, 200]);
  const [priceRange, setPriceRange] = useState([0, 1000000]);

  const handleRoomsFilterChange = (event) => setRoomsFilter(event.target.value);
  const handleFloorFilterChange = (event) => setFloorFilter(event.target.value);
  const handleAreaRangeChange = (event, newValue) => setAreaRange(newValue);
  const handlePriceRangeChange = (event, newValue) => setPriceRange(newValue);
  const handleFloorButtonClick = (floor) => setFloorFilter(floor.toString());   const handleResetFilters = () => {
    setRoomsFilter('');
    setFloorFilter('');
    setAreaRange([0, 200]);
    setPriceRange([0, 1000000]);
  };

  const filteredApartments = data?.apartments.filter((apartment) => {
    const matchesRooms = apartment.rooms.toString().includes(roomsFilter);
    const matchesFloor = floorFilter ? apartment.floor === parseInt(floorFilter) : true;
    const matchesArea = apartment.area >= areaRange[0] && apartment.area <= areaRange[1];
    const matchesPrice = apartment.totalPrice >= priceRange[0] && apartment.totalPrice <= priceRange[1];
    return matchesRooms && matchesFloor && matchesArea && matchesPrice;
  });
  

  const floorButtons = data?.house?.floors ? Array.from({ length: data.house.floors }, (_, i) => i + 1) : [];

  return (
    <Box 
          sx={{ 
            py: 8,
            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
            minHeight: '100vh'
          }}
        >
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box 
        sx={{ 
          mb: 5, 
          textAlign: 'center',
          position: 'relative',
          '&::after': {
            content: '""',
            position: 'absolute',
            bottom: -10,
            left: '50%',
            width: 60,
            height: 4,
            backgroundColor: '#FF8C00',
            transform: 'translateX(-50%)'
          }
        }}
      >
        <Typography 
          variant="h3" 
          fontWeight="700"
          sx={{
            position: 'relative',
            display: 'inline-block',
          }}
        >
          Квартиры
        </Typography>
        {data?.house?.name && (
          <Typography variant="h6" sx={{ mt: 1, color: 'text.secondary' }}>
            {data.house.name}
          </Typography>
        )}
      </Box>

      <Grid container spacing={4}>
        <Grid item xs={12} md={3}>
          <Paper 
            elevation={0}
            sx={{ 
              padding: 0,
              borderRadius: 2,
              border: '1px solid',
              borderColor: '#e0e0e0',
              backgroundColor: 'white',
              position: 'sticky',
              top: 20,
              overflow: 'hidden'
            }}
          >
            <Box sx={{ 
              padding: 2,
              display: 'flex', 
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #f0f0f0',
            }}>
              <Typography variant="h6" fontWeight={600} sx={{ fontSize: '16px' }}>
                Filters
              </Typography>
              <Button 
                onClick={handleResetFilters}
                sx={{ 
                  color: '#777', 
                  fontSize: '14px',
                  textTransform: 'none',
                  '&:hover': {
                    backgroundColor: 'transparent',
                    color: '#FF8C00'
                  }
                }}
              >
                Сбросить
              </Button>
            </Box>

            <Accordion disableGutters elevation={0} square sx={{ '&:before': { display: 'none' } }}>
              <AccordionSummary
                expandIcon={<ExpandMore />}
                sx={{ 
                  borderBottom: '1px solid #f0f0f0',
                  minHeight: '48px',
                  padding: '0 16px',
                  '& .MuiAccordionSummary-content': {
                    margin: '12px 0'
                  }
                }}
              >
                <Typography sx={{ fontSize: '14px', fontWeight: 500 }}>Комнаты</Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ padding: '16px', borderBottom: '1px solid #f0f0f0' }}>
                <FormControl fullWidth size="small">
                  <Select
                    value={roomsFilter}
                    onChange={handleRoomsFilterChange}
                    displayEmpty
                    inputProps={{ 'aria-label': 'Rooms filter' }}
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: '#e0e0e0',
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: '#FF8C00',
                      },
                    }}
                  >
                    <MenuItem value="">Все</MenuItem>
                    <MenuItem value="1">1-Комнатная</MenuItem>
                    <MenuItem value="2">2-Комнатная</MenuItem>
                    <MenuItem value="3">3-Комнатная</MenuItem>
                    <MenuItem value="4">4-Комнатная</MenuItem>
                  </Select>
                </FormControl>
              </AccordionDetails>
            </Accordion>

            <Accordion disableGutters elevation={0} square sx={{ '&:before': { display: 'none' } }}>
              <AccordionSummary
                expandIcon={<ExpandMore />}
                sx={{ 
                  borderBottom: '1px solid #f0f0f0',
                  minHeight: '48px',
                  padding: '0 16px',
                  '& .MuiAccordionSummary-content': {
                    margin: '12px 0'
                  }
                }}
              >
                <Typography sx={{ fontSize: '14px', fontWeight: 500 }}>Площадь</Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ padding: '16px', borderBottom: '1px solid #f0f0f0' }}>
                <Box sx={{ px: 1 }}>
                  <Slider
                    value={areaRange}
                    onChange={handleAreaRangeChange}
                    valueLabelDisplay="auto"
                    min={0}
                    max={200}
                    sx={{ 
                      color: '#FF8C00',
                      '& .MuiSlider-thumb': {
                        '&:hover, &.Mui-active': {
                          boxShadow: '0px 0px 0px 8px rgba(255, 140, 0, 0.16)',
                        }
                      }
                    }}
                  />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      {areaRange[0]} м²
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {areaRange[1]} м²
                    </Typography>
                  </Box>
                </Box>
              </AccordionDetails>
            </Accordion>

            <Accordion disableGutters elevation={0} square sx={{ '&:before': { display: 'none' } }}>
              <AccordionSummary
                expandIcon={<ExpandMore />}
                sx={{ 
                  borderBottom: '1px solid #f0f0f0',
                  minHeight: '48px',
                  padding: '0 16px',
                  '& .MuiAccordionSummary-content': {
                    margin: '12px 0'
                  }
                }}
              >
                <Typography sx={{ fontSize: '14px', fontWeight: 500 }}>Стоимость</Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ padding: '16px' }}>
                <Box sx={{ px: 1 }}>
                  <Slider
                    value={priceRange}
                    onChange={handlePriceRangeChange}
                    valueLabelDisplay="auto"
                    min={0}
                    max={1000000}
                    step={10000}
                    sx={{ 
                      color: '#FF8C00',
                      '& .MuiSlider-thumb': {
                        '&:hover, &.Mui-active': {
                          boxShadow: '0px 0px 0px 8px rgba(255, 140, 0, 0.16)',
                        }
                      }
                    }}
                  />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      ${new Intl.NumberFormat('en-US').format(priceRange[0])}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      ${new Intl.NumberFormat('en-US').format(priceRange[1])}
                    </Typography>
                  </Box>
                </Box>
              </AccordionDetails>
            </Accordion>
          </Paper>
        </Grid>

        <Grid item xs={12} md={9}>
          {error && (
            <Paper 
              sx={{ 
                p: 3, 
                textAlign: 'center', 
                mb: 3, 
                backgroundColor: alpha('#f44336', 0.1),
                border: '1px solid',
                borderColor: alpha('#f44336', 0.3),
                borderRadius: 2,
              }}
            >
              <Typography color="error">
                Ошибка загрузки данных: {error.message}
              </Typography>
            </Paper>
          )}
          
          {isLoading && (
            <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
              <CircularProgress sx={{ color: '#FF8C00' }} />
            </Box>
          )}

          {!isLoading && filteredApartments && filteredApartments.length > 0 ? (
            <>
              
              <Grid container spacing={3}>
                {filteredApartments.map((apartment) => (
                  <Grid key={apartment.id} item xs={12} sm={6} md={4}>
                    <ApartmentItem apartments={apartment} />
                  </Grid>
                ))}
              </Grid>
            </>
          ) : (
            !isLoading && (
              <Paper 
                sx={{ 
                  p: 5, 
                  textAlign: 'center',
                  borderRadius: 2,
                  backgroundColor: alpha('#FF8C00', 0.05),
                  border: '1px dashed',
                  borderColor: alpha('#FF8C00', 0.3),
                }}
              >
                <Typography variant="h6" sx={{ mb: 1, color: 'text.secondary' }}>
                  Нет квартир, соответствующих фильтрам
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Попробуйте изменить параметры фильтрации
                </Typography>
              </Paper>
            )
          )}
        </Grid>
      </Grid>

      <Paper 
        elevation={4}
        sx={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          p: 2,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 2,
          zIndex: 100,
          backgroundColor: 'white',
          borderTop: '1px solid',
          borderTopColor: alpha('#FF8C00', 0.2),
          boxShadow: '0px -4px 10px rgba(0, 0, 0, 0.05)',
        }}
      >
        <Typography variant="h6" fontWeight={700} sx={{ mr: 1 }}>
          Этаж:
        </Typography>
        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', justifyContent: 'center' }}>
          {floorButtons.map((floor) => {
            const hasApartmentsOnFloor = data?.apartments.some((apartment) => apartment.floor === floor);
            return (
              <Button
                key={floor}
                variant={floor.toString() === floorFilter ? 'contained' : 'outlined'}
                onClick={() => handleFloorButtonClick(floor)}
                disabled={!hasApartmentsOnFloor}
                sx={{
                  minWidth: '40px',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  p: 0,
                  fontWeight: 700,
                  borderWidth: floor.toString() === floorFilter ? 0 : 1,
                  borderColor: hasApartmentsOnFloor ? alpha('#FF8C00', 0.5) : 'divider',
                  color: floor.toString() === floorFilter ? 'white' : hasApartmentsOnFloor ? '#FF8C00' : 'text.disabled',
                  backgroundColor: floor.toString() === floorFilter ? '#FF8C00' : 'transparent',
                  '&:hover': {
                    backgroundColor: floor.toString() === floorFilter
                      ? '#E67E00'
                      : hasApartmentsOnFloor
                        ? alpha('#FF8C00', 0.1)
                        : 'transparent',
                  },
                }}
              >
                {floor}
              </Button>
            );
          })}
        </Box>
      </Paper>
    </Container>
    </Box>
  );
};

export default ApartmentContainer;