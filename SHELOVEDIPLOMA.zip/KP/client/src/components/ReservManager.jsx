import React, { useState } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  CircularProgress,
  Button,
} from '@mui/material';
import { reservAPI } from '../services/ReservService';

const BookingManagement = () => {
  const { data: bookings = [], isLoading, refetch } = reservAPI.useGetReservationsQuery()
  const [deleteBooking] = reservAPI.useDeleteReservationMutation()

  const handleDeleteBooking = async (id) => {
    await deleteBooking(id).unwrap();
    refetch();
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ mb: 3 }}>
        Управление бронированиями
      </Typography>

      <Table>
        <TableHead>
          <TableRow>
            <TableCell>ID</TableCell>
            <TableCell>ID пользователя</TableCell>
            <TableCell>ID дома</TableCell>
            <TableCell>ID квартиры</TableCell>
            <TableCell>Дата бронирования</TableCell>
            <TableCell>Действия</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {bookings.map((booking) => (
            <TableRow key={booking.id}>
              <TableCell>{booking.id}</TableCell>
              <TableCell>{booking.userId }</TableCell>
              <TableCell>{booking.houseId  }</TableCell>
              <TableCell>{booking.apartmentsId}</TableCell>
              <TableCell>{new Date(booking.reservationDate).toLocaleString()}</TableCell>
              <TableCell>
                <Button color="error" onClick={() => handleDeleteBooking(booking.id)}>
                  Удалить
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  );
};

export default BookingManagement;
