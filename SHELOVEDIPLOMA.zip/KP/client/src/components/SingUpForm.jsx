import * as React from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { useForm } from "react-hook-form";
import { Context } from "../index";
import { useContext } from 'react';
import { Navigate } from "react-router-dom";

export default function SignUp() {
  const { store } = useContext(Context);
  const [isRedirect, setIsRedirect] = React.useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm();

  const password = watch("password");

  const onSubmit = async (data) => {
    console.log(data);
    const { surname, name, email, password } = data;
    store.registration({ surname, name, email, password });
    setIsRedirect(true);
  };

  if (isRedirect) {
    return <Navigate to="/" />;
  }

  return (
    <Container component="main" maxWidth="xs" sx={{ color: '#000000' }}>
      <Box s={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h1" variant="h5">
          Регистрация
        </Typography>
        <Box
          component="form"
          onSubmit={handleSubmit(onSubmit)}
          sx={{
            mt: 3,
            color: '#000000',
            '& .MuiInputBase-root': {
              color: '#000000',
              '& fieldset': {
                borderColor: '#000000',
              },
              '& input::placeholder': {
                color: '#000000',
              },
            },
          }}
        >
          <Grid container spacing={2} sx={{ color: '#000000' }}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                placeholder="Фамилия"
                {...register('surname', {
                  required: 'Введите данные',
                  pattern: {
                    value: /^[A-Za-zА-Яа-яЁё]+$/,
                    message: 'Допустимы только буквы',
                  },
                  minLength: {
                    value: 3,
                    message: 'Минимум 3 символа',
                  },
                })}
                error={Boolean(errors.surname)}
                helperText={errors.surname?.message}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                placeholder="Имя"
                {...register('name', {
                  required: 'Введите данные',
                  pattern: {
                    value: /^[A-Za-zА-Яа-яЁё]+$/,
                    message: 'Допустимы только буквы',
                  },
                  minLength: {
                    value: 3,
                    message: 'Минимум 3 символа',
                  },
                })}
                error={Boolean(errors.name)}
                helperText={errors.name?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                placeholder="Email"
                {...register('email', {
                  required: 'Введите данные',
                  pattern: {
                    value: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/i,
                    message: 'Неправильный формат email',
                  },
                })}
                error={Boolean(errors.email)}
                helperText={errors.email?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                placeholder="Пароль"
                type="password"
                {...register('password', {
                  required: 'Введите данные',
                  pattern: {
                    value: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/,
                    message: 'Пароль должен содержать как минимумодну заглавную букву и одну цифру',
                  },
                })}
                error={Boolean(errors.password)}
                helperText={errors.password?.message}
              />
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Зарегистрироваться
          </Button>
          <Grid container justifyContent="flex-end">
            <Grid item>
              <Link href="/login" variant="body2">
                Уже есть аккаунт? Войти
              </Link>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Container>
  );
}