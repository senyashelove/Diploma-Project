import React, { useContext, useState } from 'react';
import { AppBar, Toolbar, Typography, Avatar, Box, MenuItem, Menu, Button } from '@mui/material';
import { Context } from "../index";
import { NavLink, useNavigate } from 'react-router-dom';

const Header = () => {
    const { store } = useContext(Context);
    const [anchorEl, setAnchorEl] = useState(null);
    const navigate = useNavigate();

    const handleMenuOpen = (event) => setAnchorEl(event.currentTarget);
    const handleMenuClose = () => setAnchorEl(null);
    const handleLogout = () => store.logout();
    const handleProfile = () => navigate('/profile');
    const handleCalculator = () => navigate('/calculator');

    const StyledNavLink = (props) => (
        <NavLink {...props} style={{ textDecoration: 'none', color: 'inherit', fontWeight: 'inherit' }} />
    );

    return (
        <AppBar position="static" sx={{ backgroundColor: '#2C2C2C', boxShadow: 'none' }}>
            <Toolbar sx={{ minHeight: '64px', px: 2, display: 'flex', justifyContent: 'space-between' }}>
                <Typography
                    variant="h5"
                    component={NavLink}
                    to="/house"
                    sx={{
                        fontWeight: 'bold',
                        color: 'white',
                        textDecoration: 'none',
                        ':hover': { color: '#FFA726' },
                        cursor: 'pointer',
                    }}
                >
                    EASYREALTH
                </Typography>

                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    {/* Кнопка рекламных постов — всегда видна */}
                    <StyledNavLink to="/posts">
                        <Button
                            variant="outlined"
                            color="success"
                            sx={{
                                color: '#FFF',
                                fontWeight: 'bold',
                                textTransform: 'none',
                                mr: 2,
                                ':hover': { backgroundColor: '#43a047' },
                            }}
                        >
                            Рекламные Посты
                        </Button>
                    </StyledNavLink>

                    {store.user.name ? (
                        <>
                            {store.user.role === 'ADMIN' && (
                                <Button
                                    variant="outlined"
                                    color="info"
                                    component={NavLink}
                                    to="/admin"
                                    sx={{
                                        color: '#FFF',
                                        fontWeight: 'bold',
                                        textTransform: 'none',
                                        mr: 2,
                                        ':hover': { backgroundColor: '#0288D1' },
                                    }}
                                >
                                    Админская панель
                                </Button>
                            )}

                            <Button
                                variant="outlined"
                                color="warning"
                                onClick={handleCalculator}
                                sx={{
                                    color: '#FFF',
                                    fontWeight: 'bold',
                                    textTransform: 'none',
                                    mr: 2,
                                    ':hover': { backgroundColor: '#FF9800' },
                                }}
                            >
                                Калькулятор
                            </Button>

                            <StyledNavLink to="/favorites">
                                <Button
                                    variant="outlined"
                                    color="secondary"
                                    sx={{
                                        color: '#FFF',
                                        fontWeight: 'bold',
                                        textTransform: 'none',
                                        mr: 2,
                                        ':hover': { backgroundColor: '#dc004e' },
                                    }}
                                >
                                    Избранные
                                </Button>
                            </StyledNavLink>

                            <Typography
                                variant="subtitle1"
                                sx={{
                                    mr: 1,
                                    fontWeight: 'bold',
                                    color: '#FFF',
                                    ':hover': { color: '#FFA726' },
                                }}
                            >
                                {store.user.name}
                            </Typography>

                            <Box
                                sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
                                onClick={handleMenuOpen}
                            >
                                <Avatar
                                    sx={{
                                        bgcolor: '#FFA726',
                                        width: 40,
                                        height: 40,
                                        fontSize: '1rem',
                                        ':hover': { opacity: 0.9 },
                                    }}
                                >
                                    {store.user.name.charAt(0)}
                                </Avatar>
                            </Box>

                            <Menu
                                anchorEl={anchorEl}
                                open={Boolean(anchorEl)}
                                onClose={handleMenuClose}
                                PaperProps={{
                                    sx: {
                                        backgroundColor: '#3C3C3C',
                                        color: '#FFF',
                                        borderRadius: '10px',
                                        boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
                                    },
                                }}
                            >
                                <MenuItem onClick={handleProfile} sx={{ ':hover': { backgroundColor: '#505050' } }}>
                                    Профиль
                                </MenuItem>
                                <MenuItem onClick={handleLogout} sx={{ ':hover': { backgroundColor: '#505050' } }}>
                                    Выйти
                                </MenuItem>
                            </Menu>
                        </>
                    ) : (
                        <>
                            <Button
                                component={NavLink}
                                to="/login"
                                variant="contained"
                                color="warning"
                                sx={{
                                    color: '#FFF',
                                    fontWeight: 'bold',
                                    textTransform: 'none',
                                    ':hover': { backgroundColor: '#FF9800' },
                                }}
                            >
                                Войти
                            </Button>
                            <Avatar sx={{ bgcolor: 'gray', width: 40, height: 40, ml: 2 }}>?</Avatar>
                        </>
                    )}
                </Box>
            </Toolbar>
        </AppBar>
    );
};

export default Header;
