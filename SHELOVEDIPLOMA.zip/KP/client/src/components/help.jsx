import React, { useState } from 'react';
import { Button, Box, TextField, Typography } from '@mui/material';

const Help = () => {
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState('Введите описание дизайна квартиры или Помощь для подсказки\n');
  const [isLoading, setIsLoading] = useState(false);

  const requestSupportChat = async () => {
    if (message.trim() === '') return;

    setChatHistory((prevHistory) => prevHistory + `User: ${message}\n`);
    setIsLoading(true);

    try {
      const response = await fetch('https://localhost:5000/generate-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ prompt: message }), // Отправляем сообщение как prompt
      });

      if (!response.ok) {
        const errorData = await response.json();
        setChatHistory((prevHistory) =>
          prevHistory + `Server: Ошибка при генерации изображения. ${errorData.message}\n`
        );
        return;
      }

      const data = await response.json();
      if (data.imageUrl) { // Используем imageUrl из ответа
        setChatHistory((prevHistory) =>
          prevHistory + `Server: Изображение сгенерировано успешно. См. ниже.\n`
        );
        // Отображаем сгенерированное изображение
        setChatHistory((prevHistory) =>
          prevHistory + `Generated Image: \n<img src="${data.imageUrl}" alt="Generated Image" style="max-width: 100%; height: auto;" />\n`
        );
      }
    } catch (error) {
      setChatHistory((prevHistory) =>
        prevHistory + `Server: Ошибка сервера. Попробуйте позже.\n`
      );
    } finally {
      setIsLoading(false);
      setMessage('');
    }
  };

  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: 700,
        margin: '0 auto',
        padding: 2,
        backgroundColor: '#fff',
        borderRadius: 3,
        boxShadow: 3,
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
      }}
    >
      <Typography variant="h5" color="#2C2C2C" align="center" gutterBottom>
        Помощь
      </Typography>

      <Box
        sx={{
          height: 350,
          overflowY: 'auto',
          border: '1px solid #ccc',
          backgroundColor: '#fafafa',
          borderRadius: 2,
          padding: 2,
          fontFamily: 'Roboto, sans-serif',
          whiteSpace: 'pre-wrap',
          wordWrap: 'break-word',
          overflowWrap: 'break-word',
          marginBottom: 2,
        }}
      >
        {chatHistory}
      </Box>

      <TextField
        variant="outlined"
        fullWidth
        multiline
        rows={4}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Введите сообщение..."
        sx={{
          marginBottom: 2,
          borderRadius: 2,
          '& .MuiOutlinedInput-root': {
            borderRadius: '8px',
          },
        }}
      />

      <Button
        variant="contained"
        fullWidth
        sx={{
          padding: '12px',
          backgroundColor: 'rgb(19, 19, 19)',
          color: 'white',
          '&:hover': {
            backgroundColor: '#1c1c1c',
          },
        }}
        onClick={requestSupportChat}
        disabled={isLoading} // Блокировка кнопки во время загрузки
      >
        {isLoading ? 'Отправка...' : 'Отправить'}
      </Button>
    </Box>
  );
};

export default Help;
