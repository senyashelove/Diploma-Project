import React, { useContext } from 'react';
import { houseAPI } from '../services/houseService.js';
import HouseItem from './HouseItem';
import { Box, Container, Typography, Grid, CircularProgress, Alert, Fade } from '@mui/material';
import { Context } from '../index';

const HouseContainer = () => {
  const { data, error, isLoading, refetch } = houseAPI.useFetchAllHousesQuery();
  const { store } = useContext(Context);

  return (
    <Box 
      sx={{ 
        py: 8,
        background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
        minHeight: '100vh'
      }}
    >
      <Container maxWidth="xl">
        <Typography 
          variant="h2" 
          component="h1" 
          align="center" 
          sx={{ 
            mb: 6, 
            fontWeight: 800,
            letterSpacing: '-0.025em',
            color: 'orange',
            textShadow: '0px 2px 4px rgba(0,0,0,0.1)'
          }}
        >
          ЖК "Технолог"
        </Typography>
        
        {error && (
          <Fade in={true} timeout={800}>
            <Alert 
              severity="error" 
              variant="filled"
              sx={{ 
                mb: 4, 
                width: '100%', 
                borderRadius: '10px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }}
            >
              Ошибка загрузки данных: {error.message}
            </Alert>
          </Fade>
        )}
        
        {isLoading ? (
          <Box 
            sx={{ 
              display: 'flex', 
              justifyContent: 'center', 
              alignItems: 'center', 
              minHeight: '50vh',
              flexDirection: 'column',
              gap: 2
            }}
          >
            <CircularProgress size={60} thickness={4} sx={{ color: '#9b87f5' }} />
            <Typography variant="h6" sx={{ color: '#1A1F2C', fontWeight: 500 }}>
              Загрузка данных...
            </Typography>
          </Box>
        ) : (
          <Fade in={true} timeout={1000}>
            <Grid 
              container 
              spacing={4} 
              sx={{ 
                justifyContent: 'center',
                alignItems: 'stretch'
              }}
            >
              {data && data.map(house => (
                <Grid
                  key={house.id}
                  item
                  xs={12}
                  sm={6}
                  md={4}
                  lg={4}
                  sx={{
                    display: 'flex',
                    transition: 'transform 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                    }
                  }}
                >
                  <HouseItem house={house} />
                </Grid>
              ))}
            </Grid>
          </Fade>
        )}
      </Container>
    </Box>
  );
};

export default HouseContainer;