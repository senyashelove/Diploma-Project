import React, { useEffect, useState } from 'react';
import { houseAPI } from '../services/houseService.js';
import { apartmentAPI } from '../services/ApartmentService.js';
import { postAPI } from '../services/PostService.js';
import {
  Box,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  CircularProgress,
  Tabs,
  Tab,
  Chip,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import BookingManagement from './ReservManager.jsx';
import UserList from './UserManager.jsx';
import BookingChart from './BookingChart';


const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState(0);

  const { data: posts = [], refetch: refetchPosts } = postAPI.useGetAllPostsQuery();
  const [createPost] = postAPI.useCreatePostMutation();
  const [updatePost] = postAPI.useUpdatePostMutation();
  const [deletePost] = postAPI.useDeletePostMutation();
  const [newPost, setNewPost] = useState({ text: '' });
  const [postImage, setPostImage] = useState(null);
  const [editPost, setEditPost] = useState(null);
  const [postImageUpdate, setPostImageUpdate] = useState(null);
  
const handleCreatePost = async () => {
    if (newPost.text && postImage) {
      await createPost({ newPost, postImage }).unwrap();
      refetchPosts();
      setNewPost({ text: '' });
      setPostImage(null);
    }
  };

  const handleUpdatePost = async () => {
    if (editPost) {
      await updatePost({ id: editPost.id, updatedPost: editPost, postImage: postImageUpdate }).unwrap();
      refetchPosts();
      setEditPost(null);
      setPostImageUpdate(null);
    }
  };

  const handlePhotoPostChange = (e) => {
    const file = e.target.files[0];
    setPostImage(file);
  };

  const handlePhotoUpdatePostChange = (e) => {
    const file = e.target.files[0];
    setPostImageUpdate(file);
  };

  // Houses
  const { data: houses = [], isLoading: isLoadingHouses, refetch } = houseAPI.useFetchAllHousesQuery();
  const [floors, setFloors] = useState([]);
  const [createHouse] = houseAPI.useCreateHouseMutation();
  const [deleteHouse] = houseAPI.useDeleteHouseMutation();
  const [updateHouse] = houseAPI.useUpdateHouseMutation();
  const [newHouse, setNewHouse] = useState({ name: '', address: '', floors: '' });
  const [editHouse, setEditHouse] = useState(null);
  const [photo, setPhoto] = useState(null);
  const [photoUpdate, setPhotoUpdate] = useState(null);

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    setPhoto(file);
  };
  const handlePhotoUpdateChange = (e) => {
    const file = e.target.files[0];
    console.log('dkdkd');
    setPhotoUpdate(file);
  };

  // Apartments
  const { data: apartments = [], isLoading: isLoadingApartments, refetch: refetchApart } = apartmentAPI.useGetApartmentsQuery();
  const [createApartment] = apartmentAPI.useCreateApartmentMutation();
  const [deleteApartment] = apartmentAPI.useDeleteApartmentMutation();
  const [soldApartment] = apartmentAPI.useSoldApartmentMutation();
  const [updateApartment] = apartmentAPI.useUpdateApartmentMutation();
  const [newApartment, setNewApartment] = useState({
    name: '',
    houseId: '',
    floor: '',
    rooms: '',
    area: '',
    pricePerM2: '',
    totalPrice: '',
  });
  const [editApartment, setEditApartment] = useState(null);
  const [photoApartment, setPhotoApartment] = useState(null);
  const [photoUpdateApartment, setPhotoUpdateApartment] = useState(null);

  const handleHouseChange = (event) => {
    const selectedHouseId = event.target.value;
    setNewApartment({ ...newApartment, houseId: selectedHouseId, floor: '' });
    const selectedHouse = houses.find((house) => house.id === selectedHouseId);

    if (selectedHouse) {
      const floorList = Array.from({ length: selectedHouse.floors }, (_, index) => index + 1);
      setFloors(floorList);
    } else {
      setFloors([]);
    }
  };

  const handlePhotoApartmentChange = (e) => {
    const file = e.target.files[0];
    setPhotoApartment(file);
  };
  const handlePhotoUpdateApartmentChange = (e) => {
    const file = e.target.files[0];
    console.log('dkdkd');
    setPhotoUpdateApartment(file);
  };

  const handleCreateHouse = async () => {
    if (newHouse.name && newHouse.address && newHouse.floors) {
      await createHouse({ newHouse, housePhoto: photo }).unwrap();
      refetch();
      setNewHouse({ name: '', address: '', floors: '' });
      setPhoto(null);
    }
  };

  const handleDeleteHouse = async (id) => {
    await deleteHouse(id).unwrap();
    refetch();
  };

  const handleSoldApart = async (id) => {
    await soldApartment(id).unwrap();
    refetchApart();
  };

  const handleUpdateHouse = async () => {
    if (editHouse) {
      await updateHouse({ editHouse, housePhoto: photoUpdate }).unwrap();
      refetch();
      setEditHouse(null);
    }
  };


  const handleCreateApartment = async () => {
    if (
      newApartment.name &&
      newApartment.houseId &&
      newApartment.floor &&
      newApartment.rooms &&
      newApartment.area &&
      newApartment.pricePerM2 &&
      newApartment.totalPrice
    ) {
      await createApartment({ newApartment, apartmentImage: photoApartment }).unwrap();
      refetchApart();
      setNewApartment({
        name: '',
        houseId: '',
        floor: '',
        rooms: '',
        area: '',
        pricePerM2: '',
        totalPrice: '',
      });
    }
    setPhotoApartment(null);
  };

  const handleUpdateApartment = async () => {
    if (editApartment) {
      await updateApartment({ editApartment, apartmentImage: photoUpdateApartment }).unwrap();
      refetchApart();
      setEditApartment(null);
    }
  };

  useEffect(() => {
    if (newApartment.area && newApartment.pricePerM2) {
      const totalPrice = parseFloat(newApartment.area) * parseFloat(newApartment.pricePerM2);
      setNewApartment((prev) => ({ ...prev, totalPrice: totalPrice.toFixed(2) }));
    }
  }, [newApartment.area, newApartment.pricePerM2]);

  if (isLoadingHouses || isLoadingApartments) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ mb: 3 }}>
        Панель администратора
      </Typography>

      <Tabs value={activeTab} onChange={(e, newValue) => setActiveTab(newValue)}>
        <Tab label="Управление домами" />
        <Tab label="Управление квартирами" />
        <Tab label="Бронирования" />
        <Tab label="Пользователи" />
        <Tab label="Посты" />
      </Tabs>

      {activeTab === 0 && (
        <>
          <Typography variant="h5" sx={{ mt: 3 }}>
            Управление домами
          </Typography>

          {/* Добавление дома */}
          <Box sx={{ mt: 3 }}>
            <Typography variant="h6">Добавить новый дом</Typography>
            <Box sx={{ display: 'flex', flexDirection: 'row', gap: '20px', alignItems: 'center' }}>
              <TextField
                label="Название"
                value={newHouse.name}
                onChange={(e) => setNewHouse({ ...newHouse, name: e.target.value })}
              />
              <TextField
                label="Адрес"
                value={newHouse.address}
                onChange={(e) => setNewHouse({ ...newHouse, address: e.target.value })}
              />
              <TextField
                label="Этажи"
                value={newHouse.floors}
                onChange={(e) => setNewHouse({ ...newHouse, floors: e.target.value })}
              />
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoChange}
                style={{ display: 'none' }}
                id="photo-input-create"
              />
              <label htmlFor="photo-input-create">
                <Button variant="outlined" component="span">
                  Загрузить фото
                </Button>
              </label>
              {photo && (
                <div style={{ margin: '20px' }}>
                  <img
                    src={URL.createObjectURL(photo)}
                    alt="Preview"
                    style={{ maxWidth: '300px', maxHeight: '300px' }}
                  />
                </div>
              )}
              <Button variant="contained" onClick={handleCreateHouse}>
                Добавить
              </Button>
            </Box>
          </Box>

          {/* Редактирование дома */}
          {editHouse && (
            <Box sx={{ mt: 3 }}>
              <Typography variant="h6">Редактировать дом</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'row', gap: '20px', alignItems: 'center' }}>
                <TextField
                  label="Название"
                  value={editHouse.name}
                  onChange={(e) => setEditHouse({ ...editHouse, name: e.target.value })}
                />
                <TextField
                  label="Адрес"
                  value={editHouse.address}
                  onChange={(e) => setEditHouse({ ...editHouse, address: e.target.value })}
                />
                <TextField
                  label="Этажи"
                  value={editHouse.floors}
                  onChange={(e) => setEditHouse({ ...editHouse, floors: e.target.value })}
                />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpdateChange}
                  style={{ display: 'none' }}
                  id="photo-input-update"
                />
                <label htmlFor="photo-input-update">
                  <Button variant="outlined" component="span">
                    Загрузить фото
                  </Button>
                </label>
                {photoUpdate && (
                  <div style={{ margin: '20px' }}>
                    <img
                      src={URL.createObjectURL(photoUpdate)}
                      alt="Preview"
                      style={{ maxWidth: '300px', maxHeight: '300px' }}
                    />
                  </div>
                )}
                <Button variant="contained" onClick={handleUpdateHouse}>
                  Сохранить
                </Button>
                <Button variant="outlined" onClick={() => setEditHouse(null)}>
                  Отмена
                </Button>
              </Box>
            </Box>
          )}
          <Table sx={{ marginTop: '40px' }}>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Название</TableCell>
                <TableCell>Адрес</TableCell>
                <TableCell>Этажи</TableCell>
                <TableCell>Действия</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {houses.map((house) => (
                <TableRow key={house.id}>
                  <TableCell>{house.id}</TableCell>
                  <TableCell>{house.name}</TableCell>
                  <TableCell>{house.address}</TableCell>
                  <TableCell>{house.floors}</TableCell>
                  <TableCell>
                    <Button color="primary" onClick={() => setEditHouse(house)}>
                      Изменить
                    </Button>
                    <Button color="error" onClick={() => { deleteHouse(house.id).unwrap(); refetch() }}>
                      Удалить
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </>
      )}


      {activeTab === 1 && (
        <>
          <Box sx={{ mt: 3 }}>
            <Typography variant="h6">Добавить новую квартиру</Typography>
            <Box sx={{ display: 'flex', flexDirection: 'row', gap: '20px', alignItems: 'center' }}>
              <TextField
                label="Название"
                value={newApartment.name}
                onChange={(e) => setNewApartment({ ...newApartment, name: e.target.value })}
              />
              <FormControl sx={{ width: '100px' }}>
                <InputLabel id="house-select-label">Дом ID</InputLabel>
                <Select
                  labelId="house-select-label"
                  value={newApartment.houseId}
                  onChange={handleHouseChange}
                >
                  {houses.map((house) => (
                    <MenuItem key={house.id} value={house.id}>
                      {house.id}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl sx={{ width: '100px' }} disabled={!floors.length}>
                <InputLabel id="floor-select-label">Этаж</InputLabel>
                <Select
                  labelId="floor-select-label"
                  value={newApartment.floor}
                  onChange={(e) => setNewApartment({ ...newApartment, floor: e.target.value })}
                >
                  {floors.map((floor) => (
                    <MenuItem key={floor} value={floor}>
                      {floor}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <TextField
                label="Комнаты"
                value={newApartment.rooms}
                onChange={(e) => setNewApartment({ ...newApartment, rooms: e.target.value })}
              />
              <TextField
                label="Площадь"
                value={newApartment.area}
                onChange={(e) => setNewApartment({ ...newApartment, area: e.target.value })}
              />
              <TextField
                label="Стоимость за м²"
                value={newApartment.pricePerM2}
                onChange={(e) => setNewApartment({ ...newApartment, pricePerM2: e.target.value })}
              />
              <TextField
                label="Общая стоимость"
                value={newApartment.totalPrice}
                onChange={(e) => setNewApartment({ ...newApartment, totalPrice: e.target.value })}
              />
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoApartmentChange}
                style={{ display: 'none' }}
                id="photo-input-create-apart"
              />
              <label htmlFor="photo-input-create-apart">
                <Button variant="outlined" component="span">
                  Загрузить фото
                </Button>
              </label>
              {photoApartment && (
                <div style={{ margin: '20px' }}>
                  <img
                    src={URL.createObjectURL(photoApartment)}
                    alt="Preview"
                    style={{ maxWidth: '300px', maxHeight: '300px' }}
                  />
                </div>
              )}
              <Button variant="contained" onClick={handleCreateApartment}>
                Добавить
              </Button>
            </Box>
          </Box>

          {/* Редактирование квартиры */}
          {editApartment && (
            <Box sx={{ mt: 3 }}>
              <Typography variant="h6">Редактировать квартиру</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'row', gap: '20px', alignItems: 'center' }}>
                <TextField
                  label="Название"
                  value={editApartment.name}
                  onChange={(e) => setEditApartment({ ...editApartment, name: e.target.value })}
                />
                <TextField
                  label="Дом ID"
                  value={editApartment.houseId}
                  onChange={(e) => setEditApartment({ ...editApartment, houseId: e.target.value })}
                />
                <TextField
                  label="Этаж"
                  value={editApartment.floor}
                  onChange={(e) => setEditApartment({ ...editApartment, floor: e.target.value })}
                />
                <TextField
                  label="Комнаты"
                  value={editApartment.rooms}
                  onChange={(e) => setEditApartment({ ...editApartment, rooms: e.target.value })}
                />
                <TextField
                  label="Площадь"
                  value={editApartment.area}
                  onChange={(e) => setEditApartment({ ...editApartment, area: e.target.value })}
                />
                <TextField
                  label="Стоимость за м²"
                  value={editApartment.pricePerM2}
                  onChange={(e) => setEditApartment({ ...editApartment, pricePerM2: e.target.value })}
                />
                <TextField
                  label="Общая стоимость"
                  value={editApartment.totalPrice}
                  onChange={(e) => setEditApartment({ ...editApartment, totalPrice: e.target.value })}
                />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpdateApartmentChange}
                  style={{ display: 'none' }}
                  id="photo-input-update-apart"
                />
                <label htmlFor="photo-input-update-apart">
                  <Button variant="outlined" component="span">
                    Загрузить фото
                  </Button>
                </label>
                {photoUpdateApartment && (
                  <div style={{ margin: '20px' }}>
                    <img
                      src={URL.createObjectURL(photoUpdateApartment)}
                      alt="Preview"
                      style={{ maxWidth: '300px', maxHeight: '300px' }}
                    />
                  </div>
                )}
                <Button variant="contained" onClick={handleUpdateApartment}>
                  Сохранить
                </Button>
                <Button variant="outlined" onClick={() => setEditApartment(null)}>
                  Отмена
                </Button>
              </Box>
            </Box>
          )}
          <Typography variant="h5" sx={{ mt: 3 }}>
            Управление квартирами
          </Typography>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Название</TableCell>
                <TableCell>Дом ID</TableCell>
                <TableCell>Этаж</TableCell>
                <TableCell>Комнаты</TableCell>
                <TableCell>Площадь</TableCell>
                <TableCell>Стоимость за м²</TableCell>
                <TableCell>Общая стоимость</TableCell>
                <TableCell>Статус</TableCell>
                <TableCell>Действия</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {apartments.map((apartment) => (
                <TableRow key={apartment.id}>
                  <TableCell>{apartment.id}</TableCell>
                  <TableCell>{apartment.name}</TableCell>
                  <TableCell>{apartment.houseId}</TableCell>
                  <TableCell>{apartment.floor}</TableCell>
                  <TableCell>{apartment.rooms}</TableCell>
                  <TableCell>{apartment.area}</TableCell>
                  <TableCell>{apartment.pricePerM2}</TableCell>
                  <TableCell>{apartment.totalPrice}</TableCell>
                  <TableCell>
                    <Chip
                      label={apartment.isSold ? 'Продано' : 'Доступно'}
                      color={apartment.isSold ? 'error' : 'success'}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    {!apartment.isSold && (
                      <Button color="primary" onClick={() => setEditApartment(apartment)}>
                        Изменить
                      </Button>
                    )}
                    <Button color="error" onClick={() => { deleteApartment(apartment.id).unwrap(); refetchApart(); }}>
                      Удалить
                    </Button>
                    {!apartment.isSold && (
                      <Button color="success" onClick={() => handleSoldApart(apartment.id)}>
                        Продать
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </>
      )}

      {activeTab === 2 && (
  <>
    <BookingChart />
    <BookingManagement />
  </>
)}

      {activeTab === 3 && <UserList  />}

{activeTab === 4 && (
    <>
      <Typography variant="h5" sx={{ mt: 3 }}>
        Управление постами
      </Typography>

      {/* Добавить пост */}
      <Box sx={{ mt: 3 }}>
        <Typography variant="h6">Добавить новый пост</Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: 500 }}>
          <TextField
            label="Текст поста"
            multiline
            rows={4}
            value={newPost.text}
            onChange={(e) => setNewPost({ ...newPost, text: e.target.value })}
          />
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoPostChange}
            style={{ display: 'none' }}
            id="photo-input-post"
          />
          <label htmlFor="photo-input-post">
            <Button variant="outlined" component="span">
              Загрузить изображение
            </Button>
          </label>
          {postImage && (
            <img
              src={URL.createObjectURL(postImage)}
              alt="Превью"
              style={{ maxWidth: '100%', maxHeight: 300 }}
            />
          )}
          <Button variant="contained" onClick={handleCreatePost}>
            Опубликовать
          </Button>
        </Box>
      </Box>

      {/* Редактировать пост */}
      {editPost && (
        <Box sx={{ mt: 4 }}>
          <Typography variant="h6">Редактировать пост</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: 500 }}>
            <TextField
              label="Текст поста"
              multiline
              rows={4}
              value={editPost.text}
              onChange={(e) => setEditPost({ ...editPost, text: e.target.value })}
            />
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoUpdatePostChange}
              style={{ display: 'none' }}
              id="photo-input-update-post"
            />
            <label htmlFor="photo-input-update-post">
              <Button variant="outlined" component="span">
                Заменить изображение
              </Button>
            </label>
            {postImageUpdate && (
              <img
                src={URL.createObjectURL(postImageUpdate)}
                alt="Обновленное превью"
                style={{ maxWidth: '100%', maxHeight: 300 }}
              />
            )}
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Button variant="contained" onClick={handleUpdatePost}>Сохранить</Button>
              <Button variant="outlined" onClick={() => setEditPost(null)}>Отмена</Button>
            </Box>
          </Box>
        </Box>
      )}

      <Table sx={{ marginTop: '40px' }}>
        <TableHead>
          <TableRow>
            <TableCell>ID</TableCell>
            <TableCell>Текст</TableCell>
            <TableCell>Изображение</TableCell>
            <TableCell>Действия</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {posts.map((post) => (
            <TableRow key={post.id}>
              <TableCell>{post.id}</TableCell>
              <TableCell>{post.text}</TableCell>
              <TableCell>
                <img
                  src={post.image}
                  alt="Пост"
                  style={{ width: 100, height: 'auto' }}
                />
              </TableCell>
              <TableCell>
                <Button color="primary" onClick={() => setEditPost(post)}>
                  Изменить
                </Button>
                <Button color="error" onClick={() => { deletePost(post.id).unwrap(); refetchPosts(); }}>
                  Удалить
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </>
  )}
    </Box>
  );
};

export default AdminPanel;
