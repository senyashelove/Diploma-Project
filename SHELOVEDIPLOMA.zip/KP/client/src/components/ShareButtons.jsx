import { Box } from "@mui/material";
import { FacebookShareButton, TwitterShareButton, TelegramShareButton, TelegramIcon, VKShareButton, VKIcon, FacebookIcon } from "react-share";

const ShareButtons = ({ url }) => {
    return (
        <Box display='flex' gap='10px'>
            <TelegramShareButton url={url}>
                <TelegramIcon size={35} round />
            </TelegramShareButton>
            <VKShareButton url={url}>
                <VKIcon size={35} round />
            </VKShareButton>
            <FacebookShareButton url={url}>
                <FacebookIcon size={35} round />
            </FacebookShareButton>
        </Box>
    );
};

export default ShareButtons;
