import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Context } from "../index";
import { useContext } from 'react';
import { Box, TextField, Button, Typography, MenuItem, Select, FormControl, InputLabel } from '@mui/material';
import { reservAPI, useCreateReservationMutation, useGetReservationsByDateQuery } from '../services/ReservService';

const ReservationPage = () => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const { store } = useContext(Context);
  const { apartmentId, houseId, name, image } = state || {};
  const [reservationDate, setReservationDate] = useState('');
  const [reservationTime, setReservationTime] = useState('');
  const [createReservation] = useCreateReservationMutation();
  const [availableTimes, setAvailableTimes] = useState(['13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '22:00']);

  const [isDateFocused, setIsDateFocused] = useState(false);
  const [isTimeFocused, setIsTimeFocused] = useState(false);

  const { data: existingReservations = [], refetch } = reservAPI.useGetReservationsByDateQuery({ reservationDate: reservationDate, id: apartmentId });

  useEffect(() => {
    const baseAvailableTimes = ['13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '22:00'];
    setAvailableTimes(baseAvailableTimes);
    const currentDate = new Date();
    const date = new Date();
    const currentDateWithoutTime = new Date(currentDate.setHours(0, 0, 0, 0));
    const selectedDate = new Date(reservationDate);
    const selectedDateWithoutTime = new Date(selectedDate.setHours(0, 0, 0, 0));
    if (selectedDateWithoutTime < currentDateWithoutTime) {
      setAvailableTimes([]);
      return;
    }
    if (selectedDateWithoutTime.getTime() === currentDateWithoutTime.getTime()) {
      const filteredAvailableTimes = baseAvailableTimes.filter(time => {
        const [hours, minutes] = time.split(':');
        const selectedDateTime = new Date(selectedDate);
        selectedDateTime.setHours(parseInt(hours, 10), parseInt(minutes, 10), 0, 0);
        return selectedDateTime > date;
      });
      if (existingReservations.length > 0) {

        const reservedTimes = existingReservations.map(reservation =>
          new Date(reservation.reservationDate).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
        );
        const finalFilteredTimes = filteredAvailableTimes.filter(time => !reservedTimes.includes(time));
        setAvailableTimes(finalFilteredTimes);
      } else {
        setAvailableTimes(filteredAvailableTimes);
      }
      return;
    }
    if (existingReservations.length > 0) {
      const reservedTimes = existingReservations.map(reservation =>
        new Date(reservation.reservationDate).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
      );
      const filteredAvailableTimes = baseAvailableTimes.filter(time => !reservedTimes.includes(time));
      setAvailableTimes(filteredAvailableTimes);
    } else {
      setAvailableTimes(baseAvailableTimes);
    }
  }, [reservationDate, existingReservations]);

  useEffect(() => {
    if (reservationDate) {
      refetch();
    }
  }, [reservationDate, refetch]);



  const handleSubmit = async () => {
    if (!reservationDate || !reservationTime) {
      alert('Пожалуйста, выберите дату и время.');
      return;
    }

    if (!store.user) {
      alert('Вы не авторизованы.');
      navigate('/login');
      return;
    }

    const reservationDateTime = new Date(`${reservationDate}T${reservationTime}:00`);
    const existingReservationForTime = existingReservations.find(reservation =>
      new Date(reservation.reservationDate).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) === reservationTime
    );

    if (existingReservationForTime) {
      alert('Это время уже занято.');
      return;
    }

    try {
      await createReservation({
        userId: store.user.id,
        houseId: houseId,
        apartmentsId: apartmentId,
        reservationDate: reservationDateTime,
      }).unwrap();

      alert('Бронирование успешно отправлено!');
      navigate('/profile');
    } catch (error) {
      console.error('Ошибка бронирования:', error);
      alert(`Не удалось сделать бронирование: ${error.data.message}`);
    }
  };

  return (
    <Box display='flex' alignItems='center' justifyContent='center' height='100%' marginTop='50px'>
      <Box display='flex' flexDirection='column' justifyContent='center' alignItems='center' width='500px' gap='15px'>
        <Typography variant="h4" textAlign='center' fontWeight={600} color='#FF9900'>
          Бронирование: {' '}
          <Typography component='span' fontSize='34px' color='black'>{name}</Typography>
        </Typography>
        <Box width='500px' height='350px' sx={{
          backgroundImage: `url(${image})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          border: '4px solid #FF9900'
        }}></Box>
        <TextField
          label="Выберите дату"
          type="date"
          value={reservationDate}
          onChange={(e) => setReservationDate(e.target.value)}
          onFocus={() => setIsDateFocused(true)}
          onBlur={() => setIsDateFocused(false)}
          sx={{
            mb: 2,
            width: '100%',
            '& .MuiInputBase-root.Mui-focused': {
              borderColor: isDateFocused ? '#FF9900' : '',
            },
            '& .MuiInputLabel-root.Mui-focused': {
              color: isDateFocused ? '#FF9900' : '',
            },
          }}
          InputLabelProps={{ shrink: true }}
        />
        {reservationDate && (
          <FormControl sx={{ mb: 2, width: '100%' }}>
  <InputLabel
    sx={{
      color: isTimeFocused ? '#FF9900' : '',
      '&.Mui-focused': { color: '#FF9900' },
    }}
  >
    Выберите время
  </InputLabel>
  <Select
    value={reservationTime}
    onChange={(e) => setReservationTime(e.target.value)}
    onFocus={() => setIsTimeFocused(true)}
    onBlur={() => setIsTimeFocused(false)}
    label="Выберите время"
    displayEmpty
    sx={{
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: isTimeFocused ? '0 0 4px #FF9900' : 'none',
      transition: 'all 0.3s ease-in-out',
      '& .MuiOutlinedInput-notchedOutline': {
        borderColor: isTimeFocused ? '#FF9900' : '#ccc',
      },
      '&:hover .MuiOutlinedInput-notchedOutline': {
        borderColor: '#FF9900',
      },
    }}
    MenuProps={{
      PaperProps: {
        sx: {
          borderRadius: '10px',
          mt: 1,
          backgroundColor: '#fff',
          boxShadow: '0px 4px 10px rgba(0,0,0,0.15)',
        },
      },
    }}
  >
    {availableTimes.length > 0 ? (
      availableTimes.map((time) => (
        <MenuItem
          key={time}
          value={time}
          sx={{
            paddingY: '10px',
            fontWeight: 500,
            '&:hover': {
              backgroundColor: '#FFF3E0',
              color: '#FF6F00',
            },
            '&.Mui-selected': {
              backgroundColor: '#FFE0B2 !important',
              color: '#E65100',
            },
          }}
        >
          {time}
        </MenuItem>
      ))
    ) : (
      <MenuItem disabled>Нет доступных времён</MenuItem>
    )}
  </Select>
</FormControl>

        )}

        <Button
          variant="contained"
          color="primary"
          onClick={handleSubmit}
          sx={{
            backgroundColor: '#FF8C00',
            '&:hover': { backgroundColor: '#E07B00' },
          }}
        >
          Забронировать
        </Button>
      </Box>
    </Box>
  );
};

export default ReservationPage;
