import React, { useEffect, useState, useContext } from 'react';
import { reservAPI } from '../services/ReservService';
import { Context } from "../index";
import TicketItem from './TicketItem';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import EventIcon from '@mui/icons-material/Event';

const MyReservation = () => {
  const { store } = useContext(Context);
  const { data, error, isLoading, refetch } = reservAPI.useGetReservationsByUserIdQuery(store.user.id);

  useEffect(() => {
    if (data) {
      console.log(data);
    }
  }, [data]);

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(to bottom right, #f9fafb, #f3f4f6)', padding: '24px' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <h1 style={{
          fontSize: '32px',
          fontWeight: 'bold',
          textAlign: 'center',
          marginBottom: '32px',
          background: 'linear-gradient(to right, #fb8c00, #ffca28)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          Мои Бронирования
        </h1>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '24px', justifyContent: 'center' }}>
          {data && data.map((reservation) => (
            <div
              key={reservation.id}
              style={{
                background: '#fff',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                transition: 'all 0.3s ease',
                width: '100%',
                maxWidth: '350px'
              }}
            >
              <div style={{
                background: 'linear-gradient(to right, #fb8c00, #ffca28)',
                color: '#fff',
                padding: '16px',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px'
              }}>
                <h3 style={{ fontSize: '18px', fontWeight: 'bold', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {reservation.apartments.name}
                </h3>
              </div>

              <div style={{ padding: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '16px' }}>
                  <LocationOnIcon style={{ color: '#fb8c00', marginRight: '8px', marginTop: '2px' }} />
                  <div>
                    <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '2px' }}>Адрес</p>
                    <p style={{ fontWeight: '500', color: '#111827', lineHeight: '1.4' }}>
                      {reservation.house.address}
                    </p>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '16px' }}>
                  <EventIcon style={{ color: '#ff9800', marginRight: '8px', marginTop: '2px' }} />
                  <div>
                    <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '2px' }}>Дата бронирования</p>
                    <p style={{ fontWeight: '500', color: '#111827' }}>
                      {new Date(reservation.reservationDate).toLocaleString()}
                    </p>
                  </div>
                </div>

                <div style={{ borderTop: '1px solid #e5e7eb', paddingTop: '16px' }}>
                  <TicketItem id={reservation.id} refetch={refetch} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MyReservation;
