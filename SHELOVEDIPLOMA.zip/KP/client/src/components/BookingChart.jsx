import React, { useMemo } from 'react';
import {
  Box,
  Typography,
  CircularProgress,
} from '@mui/material';
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { reservAPI } from '../services/ReservService';

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

const BookingChart = () => {
  const { data: bookings = [], isLoading } = reservAPI.useGetReservationsQuery();

  const last30DaysData = useMemo(() => {
    const now = new Date();
    const days = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(now.getDate() - i);
      return {
        date: date.toISOString().split('T')[0],
        count: 0,
      };
    }).reverse();

    const dateMap = Object.fromEntries(days.map((d) => [d.date, 0]));

    bookings.forEach((booking) => {
      const date = new Date(booking.reservationDate).toISOString().split('T')[0];
      if (dateMap[date] !== undefined) {
        dateMap[date] += 1;
      }
    });

    return Object.entries(dateMap).map(([date, count]) => ({ date, count }));
  }, [bookings]);

  const chartData = {
    labels: last30DaysData.map(d => d.date),
    datasets: [
      {
        label: 'Бронирования',
        data: last30DaysData.map(d => d.count),
        borderColor: '#8884d8',
        backgroundColor: 'rgba(136, 132, 216, 0.2)',
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: true },
      tooltip: { enabled: true },
    },
    scales: {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45,
          autoSkip: true,
        },
      },
      y: {
        beginAtZero: true,
        precision: 0,
      },
    },
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 5, height: 250 }}>
      <Typography variant="h6" gutterBottom>
        Количество бронирований за последние 30 дней
      </Typography>
      <Box sx={{ height: 200 }}>
        <Line data={chartData} options={chartOptions} />
      </Box>
    </Box>
  );
};

export default BookingChart;
