import { useContext } from 'react';
import { 
  TextField, 
  Button, 
  Box, 
  Container, 
  Typography, 
  Paper, 
  Avatar,
  Grid,
  Divider,
  IconButton,
  InputAdornment
} from '@mui/material';
import { useForm } from 'react-hook-form';
import { Edit, Save, Person, Email } from '@mui/icons-material';
import { Context } from "../index";

function ChangeProfileForm() {
    const { store } = useContext(Context);
    const {
        register,
        handleSubmit,
        formState: { errors, isDirty },
    } = useForm();

    const onSubmit = async (data) => {
        console.log(data);
        await store.update(data);
        window.location.reload();
    };

    // Получаем инициалы для аватара
    const getInitials = () => {
      if (store.user?.name && store.user?.surname) {
        return `${store.user.name.charAt(0)}${store.user.surname.charAt(0)}`;
      }
      return '?';
    };

    return (
        <Box 
          sx={{ 
            width: '100%',
            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
            borderRadius: 3,
            padding: { xs: 2, sm: 4 },
            backdropFilter: 'blur(10px)',
          }}
        >
          <Paper 
            elevation={0}
            sx={{ 
              padding: 4, 
              borderRadius: 3, 
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)'
            }}
          >
            <Box display="flex" flexDirection="column" alignItems="center" mb={4}>
              <Avatar 
                sx={{ 
                  width: 120, 
                  height: 120, 
                  bgcolor: 'primary.main',
                  fontSize: '2.5rem',
                  mb: 2,
                  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
                }}
              >
                {getInitials()}
              </Avatar>
              <Typography variant="h4" fontWeight="bold" color="primary.dark">
                {store.user?.name} {store.user?.surname}
              </Typography>
              <Typography variant="body1" color="text.secondary" mt={1}>
                {store.user?.email}
              </Typography>
            </Box>

            <Divider sx={{ my: 3 }}>
              <Typography variant="h6" color="primary" fontWeight="medium">
                Изменение данных профиля
              </Typography>
            </Divider>

            <Box 
              component="form" 
              onSubmit={handleSubmit(onSubmit)} 
              sx={{ 
                mt: 3,
                width: '100%',
                '& .MuiTextField-root': { mb: 3 },
              }}
            >
              <TextField
                fullWidth
                label="Фамилия"
                defaultValue={store.user?.surname}
                placeholder="Введите фамилию"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Person sx={{ color: 'primary.main' }} />
                    </InputAdornment>
                  ),
                }}
                {...register('surname', {
                  required: 'Введите фамилию',
                  minLength: {
                    value: 3,
                    message: 'Минимум 3 символа',
                  },
                  pattern: {
                    value: /^[A-Za-zА-Яа-яЁё]+$/,
                    message: 'Только буквы',
                  },
                })}
                error={Boolean(errors.surname)}
                helperText={errors.surname?.message}
                variant="outlined"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: 'primary.light' },
                    '&:hover fieldset': { borderColor: 'primary.main' },
                    '&.Mui-focused fieldset': { borderColor: 'primary.dark' },
                    backgroundColor: 'rgba(255, 255, 255, 0.7)',
                    borderRadius: 2,
                  },
                }}
              />

              <TextField
                fullWidth
                label="Имя"
                defaultValue={store.user?.name}
                placeholder="Введите имя"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Person sx={{ color: 'primary.main' }} />
                    </InputAdornment>
                  ),
                }}
                {...register('name', {
                  required: 'Введите имя',
                  minLength: {
                    value: 3,
                    message: 'Минимум 3 символа',
                  },
                  pattern: {
                    value: /^[A-Za-zА-Яа-яЁё]+$/,
                    message: 'Только буквы',
                  },
                })}
                error={Boolean(errors.name)}
                helperText={errors.name?.message}
                variant="outlined"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: 'primary.light' },
                    '&:hover fieldset': { borderColor: 'primary.main' },
                    '&.Mui-focused fieldset': { borderColor: 'primary.dark' },
                    backgroundColor: 'rgba(255, 255, 255, 0.7)',
                    borderRadius: 2,
                  },
                }}
              />

              <TextField
                fullWidth
                label="Email"
                defaultValue={store.user?.email}
                placeholder="Введите email"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Email sx={{ color: 'primary.main' }} />
                    </InputAdornment>
                  ),
                }}
                {...register('email', {
                  required: 'Введите email',
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: 'Неправильный формат email',
                  },
                })}
                error={Boolean(errors.email)}
                helperText={errors.email?.message}
                variant="outlined"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: 'primary.light' },
                    '&:hover fieldset': { borderColor: 'primary.main' },
                    '&.Mui-focused fieldset': { borderColor: 'primary.dark' },
                    backgroundColor: 'rgba(255, 255, 255, 0.7)',
                    borderRadius: 2,
                  },
                }}
              />

              <Button
                type="submit"
                variant="contained"
                disabled={!isDirty || Object.keys(errors).length > 0}
                startIcon={<Save />}
                sx={{
                  mt: 2,
                  py: 1.5,
                  borderRadius: 2,
                  backgroundColor: 'primary.main',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
                  '&:hover': {
                    backgroundColor: 'primary.dark',
                    boxShadow: '0 6px 16px rgba(0, 0, 0, 0.2)',
                  },
                  transition: 'all 0.3s ease',
                  width: '100%',
                  fontWeight: 'bold',
                  fontSize: '1rem',
                }}
              >
                Сохранить изменения
              </Button>
            </Box>
          </Paper>
        </Box>
    );
}

export default ChangeProfileForm;

