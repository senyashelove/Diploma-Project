import React, { useState } from 'react';
import {
  Box,
  TextField,
  MenuItem,
  Button,
  Typography,
  Grid,
} from '@mui/material';

const Calculator = () => {
  const [propertyValue, setPropertyValue] = useState('');
  const [downPayment, setDownPayment] = useState('');
  const [loanTerm, setLoanTerm] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [paymentType, setPaymentType] = useState('equal');
  const [monthlyPayment, setMonthlyPayment] = useState(0);
  const [totalPayment, setTotalPayment] = useState(0);
  const [overpayment, setOverpayment] = useState(0);
  const [overpaymentPercentage, setOverpaymentPercentage] = useState(0);
  const [endDate, setEndDate] = useState('');
  const [currency, setCurrency] = useState('$'); // Track currency ($ or RUB)

  const calculate = () => {
    const loanAmount = propertyValue - downPayment; // Сумма кредита
    const months = loanTerm * 12; // Количество месяцев
    const monthlyRate = interestRate / 100 / 12; // Месячная ставка

    let monthlyPaymentResult = 0;
    let totalPaid = 0;

    if (paymentType === 'equal') {
      // Аннуитетный платеж
      monthlyPaymentResult =
        (loanAmount * monthlyRate) /
        (1 - Math.pow(1 + monthlyRate, -months));
      totalPaid = monthlyPaymentResult * months;
    } else {
      // Дифференцированный платеж
      const principalPayment = loanAmount / months;
      totalPaid = 0;

      for (let i = 0; i < months; i++) {
        const remainingLoan = loanAmount - principalPayment * i;
        const currentInterest = remainingLoan * monthlyRate;
        totalPaid += principalPayment + currentInterest;
      }

      // Средний ежемесячный платеж
      monthlyPaymentResult = totalPaid / months;
    }

    const overpaymentAmount = totalPaid - loanAmount;
    const overpaymentPercent = (overpaymentAmount / loanAmount) * 100;

    // Рассчитать дату окончания выплат
    const currentDate = new Date();
    currentDate.setMonth(currentDate.getMonth() + months);
    const formattedEndDate = currentDate.toLocaleDateString('ru-RU', {
      month: 'long',
      year: 'numeric',
    });

    setMonthlyPayment(monthlyPaymentResult.toFixed(2));
    setTotalPayment(totalPaid.toFixed(2));
    setOverpayment(overpaymentAmount.toFixed(2));
    setOverpaymentPercentage(overpaymentPercent.toFixed(2));
    setEndDate(formattedEndDate);
  };

  const toggleCurrency = () => {
    setCurrency(currency === '$' ? 'BYN' : '$');
  };

  const handlePropertyValueChange = (e) => {
    const value = Math.max(0, +e.target.value); // Запрещаем отрицательные значения
    setPropertyValue(value);
  };

  const handleDownPaymentChange = (e) => {
    const value = Math.max(0, +e.target.value); // Запрещаем отрицательные значения, но допускаем 0
    setDownPayment(value);
  };

  const handleLoanTermChange = (e) => {
    const value = Math.max(1, +e.target.value); // Запрещаем отрицательные и нулевые значения
    setLoanTerm(value);
  };

  const handleInterestRateChange = (e) => {
    const value = Math.max(0, +e.target.value); // Запрещаем отрицательные значения
    setInterestRate(value);
  };

  return (
    <Box
      sx={{
        maxWidth: '600px',
        margin: '20px auto',
        padding: '20px',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
      }}
    >
      <Typography variant="h5" gutterBottom align="center">
        Калькулятор кредита
      </Typography>

      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label={`Стоимость недвижимости (${currency})`}
            variant="outlined"
            type="number"
            value={propertyValue}
            onChange={handlePropertyValueChange}
            sx={{
              '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgb(255, 167, 38)', // Focused border color
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: 'rgb(255, 167, 38)', // Focused label color
              },
            }}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label={`Первоначальный взнос (${currency})`}
            variant="outlined"
            type="number"
            value={downPayment}
            onChange={handleDownPaymentChange}
            sx={{
              '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgb(255, 167, 38)', // Focused border color
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: 'rgb(255, 167, 38)', // Focused label color
              },
            }}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Срок кредитования (лет)"
            variant="outlined"
            type="number"
            value={loanTerm}
            onChange={handleLoanTermChange}
            sx={{
              '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgb(255, 167, 38)', 
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: 'rgb(255, 167, 38)', 
              },
            }}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Процентная ставка (%)"
            variant="outlined"
            type="number"
            value={interestRate}
            onChange={handleInterestRateChange}
            sx={{
              '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgb(255, 167, 38)', 
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: 'rgb(255, 167, 38)', 
              },
            }}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            select
            fullWidth
            label="Тип платежа"
            value={paymentType}
            onChange={(e) => setPaymentType(e.target.value)}
            sx={{
              '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgb(255, 167, 38)', 
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: 'rgb(255, 167, 38)', 
              },
            }}
          >
            <MenuItem value="equal">Аннуитетные платежи</MenuItem>
            <MenuItem value="decreasing">Дифференцированные платежи</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      <Box sx={{ textAlign: 'center', marginTop: '20px' }}>
      <Button
  variant="contained"
  color="primary"
  onClick={calculate}
  disabled={!propertyValue || propertyValue <= 0 || !loanTerm || !interestRate}
  sx={{
    backgroundColor: 'rgb(255, 167, 38)', // Button background color
    '&:hover': {
      backgroundColor: 'rgb(255, 167, 38)', // Button hover color
    },
  }}
>
  Рассчитать
</Button>

      </Box>

      <Box sx={{ textAlign: 'center', marginTop: '20px' }}>
        <Button
          variant="outlined"
          onClick={toggleCurrency}
          sx={{
            color: 'rgb(255, 167, 38)', // Button text color
            borderColor: 'rgb(255, 167, 38)', // Button border color
            '&:hover': {
              borderColor: 'rgb(255, 167, 38)', // Button hover border color
              backgroundColor: 'rgb(255, 167, 38)', // Button hover background color
              color: '#fff', // Button hover text color
            },
          }}
        >
          Переключить валюту
        </Button>
      </Box>

      {totalPayment > 0 && (
        <Box sx={{ marginTop: '20px', padding: '10px' }}>
          <Typography variant="h6">Ежемесячный платеж: {monthlyPayment} {currency}</Typography>
          <Typography variant="h6">Общая сумма к выплате: {totalPayment} {currency}</Typography>
          <Typography variant="h6">Переплата по кредиту: {overpayment} {currency}</Typography>
          <Typography variant="h6">Процент переплаты: {overpaymentPercentage}%</Typography>
          <Typography variant="h6">Дата окончания выплат: {endDate}</Typography>
        </Box>
      )}
    </Box>
  );
};

export default Calculator;
