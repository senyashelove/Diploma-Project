// TicketItem.js
import React from 'react';
import { useDeleteReservationMutation } from '../services/ReservService';

const TicketItem = ({ id, refetch }) => {
  const [deleteReservation] = useDeleteReservationMutation();

  const handleDelete = async () => {
    try {
      await deleteReservation(id).unwrap();
      refetch();  // Обновить данные
      alert('Бронирование удалено');
    } catch (error) {
      console.error('Ошибка при удалении бронирования:', error);
      alert('Не удалось удалить бронирование');
    }
  };

  return (
    <div>
      <button
        onClick={handleDelete}
        style={{
          backgroundColor: '#ff9900',
          color: '#fff',
          border: 'none',
          padding: '10px 20px',
          fontSize: '16px',
          cursor: 'pointer',
          borderRadius: '5px',
          transition: 'background-color 0.3s',
        }}
        onMouseEnter={(e) => (e.target.style.backgroundColor = '#e68a00')}  // При наведении меняется цвет
        onMouseLeave={(e) => (e.target.style.backgroundColor = '#ff9900')}  // Возвращается исходный цвет
      >
        Удалить бронирование
      </button>
    </div>
  );
};

export default TicketItem;
