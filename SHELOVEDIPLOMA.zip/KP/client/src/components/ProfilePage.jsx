import * as React from 'react';
import { useContext } from 'react';
import { Context } from "../index";
import { 
  Box, 
  Typography, 
  Grid, 
  Paper, 
  Tab, 
  Tabs, 
  Avatar,
  Container,
  Divider
} from '@mui/material';
import { 
  Person, 
  Edit, 
  CalendarMonth, 
  Email, 
  Badge
} from '@mui/icons-material';
import ChangeProfileForm from './ChangeProfileForm';
import MyReservation from './MyReservation';

export default function ProfilePage() {
  const { store } = useContext(Context);
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };  

  // Get first letter of name and surname for avatar
  const getInitials = () => {
    if (store.user.name && store.user.surname) {
      return `${store.user.name.charAt(0)}${store.user.surname.charAt(0)}`;
    }
    return '?';
  };

  const renderContent = () => {
    switch (value) {
      case 0:
        return (
          <Box width='100%'>
            <Paper 
              elevation={0}
              sx={{ 
                padding: 4, 
                borderRadius: 3, 
                backgroundColor: 'rgba(255, 255, 255, 0.9)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)'
              }}
            >
              <Box display="flex" flexDirection="column" alignItems="center" mb={4}>
                <Avatar 
                  sx={{ 
                    width: 120, 
                    height: 120, 
                    bgcolor: 'primary.main',
                    fontSize: '2.5rem',
                    mb: 2,
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
                  }}
                >
                  {getInitials()}
                </Avatar>
                <Typography variant="h4" fontWeight="bold" color="primary.dark">
                  {store.user.name} {store.user.surname}
                </Typography>
                <Typography variant="body1" color="text.secondary" mt={1}>
                  {store.user.email}
                </Typography>
              </Box>

              <Divider sx={{ my: 3 }} />

              <Box mt={4}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <Badge sx={{ color: 'primary.main', mr: 2, fontSize: 28 }} />
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Имя
                    </Typography>
                    <Typography variant="h6" fontWeight="medium">
                      {store.user.name}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <Badge sx={{ color: 'primary.main', mr: 2, fontSize: 28 }} />
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Фамилия
                    </Typography>
                    <Typography variant="h6" fontWeight="medium">
                      {store.user.surname}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <Email sx={{ color: 'primary.main', mr: 2, fontSize: 28 }} />
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Email-адрес
                    </Typography>
                    <Typography variant="h6" fontWeight="medium">
                      {store.user.email}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </Paper>
          </Box>
        );
      case 1:
        return <ChangeProfileForm />;
      case 2:
        return <MyReservation />;
      default:
        return null;
    }
  };

  return (
    <Box 
      sx={{ 
        background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
        minHeight: '100vh', 
        pt: 4, 
        pb: 8 
      }}
    >
      <Container maxWidth="lg">
        <Paper 
          elevation={0}
          sx={{ 
            borderRadius: 4, 
            overflow: 'hidden',
            backgroundColor: 'rgba(255, 255, 255, 0.8)',
            backdropFilter: 'blur(10px)',
            boxShadow: '0 15px 35px rgba(0, 0, 0, 0.1)'
          }}
        >
          <Grid container>
            {/* Sidebar with navigation */}
            <Grid 
              item 
              xs={12} 
              md={3}
              sx={{ 
                backgroundColor: 'primary.main',
                color: 'white',
                position: { md: 'relative' }
              }}
            >
              <Box sx={{ position: { md: 'sticky' }, top: 0, p: 2 }}>
                <Box sx={{ textAlign: 'center', py: 4 }}>
                  <Avatar 
                    sx={{ 
                      width: 80, 
                      height: 80, 
                      mx: 'auto',
                      bgcolor: 'primary.light',
                      border: '4px solid rgba(255, 255, 255, 0.2)',
                      boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
                      fontSize: '1.75rem'
                    }}
                  >
                    {getInitials()}
                  </Avatar>
                  <Typography 
                    variant="h6" 
                    sx={{ 
                      mt: 2, 
                      fontWeight: 'bold',
                      textShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
                    }}
                  >
                    {store.user.name} {store.user.surname}
                  </Typography>
                </Box>

                <Tabs
                  orientation="vertical"
                  variant="fullWidth"
                  value={value}
                  onChange={handleChange}
                  sx={{
                    '& .MuiTab-root': {
                      alignItems: 'flex-start',
                      textAlign: 'left',
                      py: 2,
                      color: 'rgba(255, 255, 255, 0.7)',
                      '&.Mui-selected': {
                        color: 'white',
                        backgroundColor: 'rgba(255, 255, 255, 0.1)',
                        borderRadius: 2,
                      },
                      '&:hover': {
                        backgroundColor: 'rgba(255, 255, 255, 0.05)',
                        borderRadius: 2,
                      },
                      transition: 'all 0.2s ease-in-out'
                    },
                    '& .MuiTabs-indicator': {
                      display: 'none',
                    }
                  }}
                >
                  <Tab 
                    icon={<Person />} 
                    iconPosition="start"
                    label="Профиль" 
                    sx={{ pl: 3 }}
                  />
                  <Tab 
                    icon={<Edit />} 
                    iconPosition="start"
                    label="Изменение данных" 
                    sx={{ pl: 3 }}
                  />
                  <Tab 
                    icon={<CalendarMonth />} 
                    iconPosition="start"
                    label="Мои Бронирования" 
                    sx={{ pl: 3 }}
                  />
                </Tabs>
              </Box>
            </Grid>

            {/* Main content area */}
            <Grid item xs={12} md={9}>
              <Box sx={{ p: { xs: 2, sm: 4 } }}>
                {renderContent()}
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </Box>
  );
}