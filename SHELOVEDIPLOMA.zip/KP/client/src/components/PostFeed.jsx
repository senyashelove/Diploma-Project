import React from 'react';
import { postAPI } from '../services/PostService';
import { Box, Card, CardMedia, CardContent, Typography, Grid, CircularProgress, Container } from '@mui/material';

const PostFeed = () => {
  const { data: posts = [], isLoading, error } = postAPI.useGetAllPostsQuery();

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
        <CircularProgress size={60} thickness={4} />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg">
        <Typography 
          color="error" 
          align="center" 
          variant="h5"
          sx={{ 
            mt: 8,
            p: 4,
            backgroundColor: '#ffebee',
            borderRadius: 2,
            border: '1px solid #ffcdd2'
          }}
        >
          Ошибка при загрузке постов.
        </Typography>
      </Container>
    );
  }

  return (
    <Box sx={{ 
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
      py: 6
    }}>
      <Container maxWidth="lg">
        <Typography 
          variant="h3" 
          sx={{ 
            mb: 6,
            textAlign: 'center',
            fontWeight: 'bold',
            background: 'linear-gradient(45deg,#FF9800 70%, #FF9801 30%)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            textShadow: '2px 2px 4px rgba(0,0,0,0.1)'
          }}
        >
          Рекламные предложения
        </Typography>
        
        <Grid container spacing={4}>
          {posts.map((post) => (
            <Grid item xs={12} key={post.id}>
             <Card 
  sx={{ 
    display: 'flex',
    height: 800,
    boxShadow: '0 12px 48px rgba(0,0,0,0.15)',
    borderRadius: 4,
    overflow: 'hidden',
    transition: 'all 0.3s ease-in-out',
    '&:hover': {
      transform: 'translateY(-12px)',
      boxShadow: '0 24px 64px rgba(0,0,0,0.2)'
    },
    background: 'linear-gradient(145deg, #ffffff 0%, #f4f4f4 100%)'
  }}
>
  <CardMedia
    component="img"
    image={post.image}
    alt="Пост"
    sx={{ 
      width: '60%',
      height: '100%',
      objectFit: 'cover'
    }}
  />
  <CardContent 
    sx={{ 
      width: '60%',
      p: 5,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #e0e0e0 0%, #bdbdbd 100%)',
      color: '#212121',
      position: 'relative',
      '&::before': {
        content: '""',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(255,255,255,0.05)',
        backdropFilter: 'blur(4px)'
      }
    }}
  >
    <Typography 
      variant="h5" 
      sx={{ 
        mb: 3,
        fontWeight: 'bold',
        textShadow: '1px 1px 1px rgba(255,255,255,0.6)',
        position: 'relative',
        zIndex: 1
      }}
    >
      Рекламное объявление
    </Typography>
    <Typography 
      variant="body1" 
      sx={{ 
        whiteSpace: 'pre-line',
        lineHeight: 1.8,
        fontSize: '1.3rem',
        textShadow: '1px 1px 1px rgba(255,255,255,0.4)',
        position: 'relative',
        zIndex: 1
      }}
    >
      {post.text}
    </Typography>
  </CardContent>
</Card>



            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default PostFeed;