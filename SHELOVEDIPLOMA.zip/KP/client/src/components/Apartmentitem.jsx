import React, { useContext, useState, useEffect } from 'react';
import Typography from '@mui/material/Typography';
import { Box, Modal, Button, Card, CardContent, Grid, Divider, Chip, Paper, IconButton, Tooltip } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { Context } from "../index";
import ShareButtons from './ShareButtons';
import { SquareFoot, Bed, Home, AttachMoney, Favorite, FavoriteBorder } from '@mui/icons-material';
import axios from 'axios';


const ApartmentItem = ({ apartments }) => {
  const navigate = useNavigate();
  const { store } = useContext(Context);
  const [open, setOpen] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  useEffect(() => {
    const checkFavoriteStatus = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;
  
        const headers = { Authorization: `${token}` };
  
        const res = await axios.get('https://localhost:5000/favorites', { headers });
  
        const isFav = res.data.some(item => 
          item.apartment?.id === apartments.id || item.apartmentsId === apartments.id
        );
        setIsFavorite(isFav);
      } catch (err) {
        console.error('Ошибка при проверке избранного:', err);
      }
    };
  
    checkFavoriteStatus();
  }, [apartments.id]);
  const currentUrl = window.location.href;

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const handlePrint = () => window.print();

  const handleNavigate = () => {
    navigate(`/reservation`, {
      state: {
        houseId: apartments.houseId,
        apartmentId: apartments.id,
        name: apartments.name,
        image: apartments.image,
      },
    });
  };

  const handleToggleFavorite = async (e) => {
    e.stopPropagation();
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      const headers = { Authorization: `${token}` };

      if (isFavorite) {
        await axios.delete(`https://localhost:5000/favorites/${apartments.id}`, { headers });
      } else {
        await axios.post(`https://localhost:5000/favorites/add`, { apartmentId: apartments.id }, { headers });
      }

      setIsFavorite(!isFavorite);
    } catch (err) {
      console.error('Ошибка при обновлении избранного:', err);
    }
  };

  return (
    <>
      <Card
        onClick={handleOpen}
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          cursor: 'pointer',
          transition: 'transform 0.3s, box-shadow 0.3s',
          '&:hover': {
            transform: 'translateY(-8px)',
            boxShadow: '0 8px 40px rgba(255, 140, 0, 0.2)',
          },
          borderRadius: 2,
          overflow: 'hidden',
          position: 'relative',
        }}
      >
        <Box
          sx={{
            position: 'relative',
            paddingTop: '70%',
            overflow: 'hidden',
            backgroundColor: '#f5f5f5',
          }}
        >
          <Box
            component="img"
            src={apartments.image}
            alt={`Квартира ${apartments.id}`}
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              objectFit: 'cover',
            }}
          />

          <Chip
            label={`${apartments.rooms} ${apartments.rooms === 1 ? 'комната' : apartments.rooms > 1 && apartments.rooms < 5 ? 'комнаты' : 'комнат'}`}
            sx={{
              position: 'absolute',
              top: 10,
              right: 10,
              backgroundColor: '#FF8C00',
              color: 'white',
              fontWeight: 'bold',
            }}
          />

          <Tooltip title={isFavorite ? "Удалить из избранного" : "Добавить в избранное"}>
            <IconButton
              onClick={handleToggleFavorite}
              sx={{ position: 'absolute', top: 10, left: 10, color: 'red' }}
            >
              {isFavorite ? <Favorite /> : <FavoriteBorder />}
            </IconButton>
          </Tooltip>
        </Box>

        <CardContent sx={{ flexGrow: 1, p: 2 }}>
          <Box sx={{ mb: 2 }}>
            <Typography variant="h6" component="div" fontWeight="bold">
              {apartments.name}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {`Этаж ${apartments.floor}`}
            </Typography>
          </Box>

          <Divider sx={{ my: 1.5 }} />

          <Grid container spacing={1} sx={{ mt: 1 }}>
            <Grid item xs={6}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <SquareFoot sx={{ color: '#FF8C00', mr: 1, fontSize: 18 }} />
                <Typography variant="body2">{`${apartments.area} м²`}</Typography>
              </Box>
            </Grid>
            <Grid item xs={6}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Bed sx={{ color: '#FF8C00', mr: 1, fontSize: 18 }} />
                <Typography variant="body2">{`${apartments.rooms} ${apartments.rooms === 1 ? 'Комната' : 'Комнаты'}`}</Typography>
              </Box>
            </Grid>
          </Grid>

          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6" fontWeight="bold" color="#FF8C00">
              {new Intl.NumberFormat('ru-RU', {
                style: 'currency',
                currency: 'USD',
                maximumFractionDigits: 0,
              }).format(apartments.totalPrice)}
            </Typography>
            <Button
              variant="contained"
              size="small"
              sx={{
                backgroundColor: '#FF8C00',
                color: 'white',
                '&:hover': {
                  backgroundColor: '#E67E00',
                },
              }}
              onClick={(e) => {
                e.stopPropagation();
                handleOpen();
              }}
            >
              Подробнее
            </Button>
          </Box>
        </CardContent>
      </Card>

      {/* Модальное окно */}
      <Modal
  open={open}
  onClose={handleClose}
  aria-labelledby="apartment-modal-title"
  aria-describedby="apartment-modal-description"
>
  <Box
    sx={{
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: { xs: '90%', sm: '80%', md: 800 },
      bgcolor: 'background.paper',
      boxShadow: '0 10px 50px rgba(0, 0, 0, 0.2)',
      p: { xs: 2, sm: 4 },
      borderRadius: '12px',
      maxHeight: '90vh',
      overflowY: 'auto',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
      '&:hover': {
        transform: 'translate(-50%, -50%) scale(1.01)',
      },
    }}
  >
    {/* Заголовок и кнопка закрытия */}
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
      <Typography
        id="apartment-modal-title"
        variant="h4"
        fontWeight={700}
        sx={{
          color: '#FF8C00',
          position: 'relative',
          display: 'inline-block',
          '&::after': {
            content: '""',
            position: 'absolute',
            bottom: -5,
            left: 0,
            width: '40%',
            height: 3,
            backgroundColor: '#FF8C00',
          },
        }}
      >
        {apartments.name}
      </Typography>
      <Button
        onClick={handleClose}
        sx={{
          minWidth: 'auto',
          width: 40,
          height: 40,
          borderRadius: '50%',
          color: '#FF8C00',
          '&:hover': {
            backgroundColor: 'rgba(255, 140, 0, 0.1)',
          },
        }}
      >
        ✕
      </Button>
    </Box>

    {/* Основное содержимое */}
    <Grid container spacing={3}>
      {/* Изображение квартиры */}
      <Grid item xs={12} md={7}>
        <Box
          component="img"
          src={apartments.image}
          alt="Планировка"
          sx={{
            width: '100%',
            height: 'auto',
            borderRadius: '8px',
            boxShadow: '0 5px 15px rgba(0, 0, 0, 0.1)',
            transition: 'transform 0.3s ease',
            '&:hover': {
              transform: 'scale(1.02)',
            },
          }}
        />
      </Grid>

      {/* Характеристики квартиры и фото дома */}
      <Grid item xs={12} md={5}>
        <Paper
          sx={{
            p: 3,
            borderRadius: '8px',
            bgcolor: 'rgba(255, 140, 0, 0.05)',
            boxShadow: '0 3px 10px rgba(0, 0, 0, 0.1)',
          }}
        >
          {/* Фото дома */}
          <Box
            component="img"
            src={apartments.house.image}
            alt="Фото дома"
            sx={{
              width: '100%',
              borderRadius: '8px',
              mb: 3,
              boxShadow: '0 3px 10px rgba(0, 0, 0, 0.1)',
            }}
          />

          {/* Характеристики квартиры */}
          <Typography variant="h6" fontWeight={600} mb={3} color="#FF8C00">
            Характеристики
          </Typography>

          <Grid container spacing={2}>
            {[
              { icon: <SquareFoot />, label: 'Площадь', value: `${apartments.area} м²` },
              { icon: <Bed />, label: 'Комнаты', value: apartments.rooms },
              { icon: <Home />, label: 'Этаж', value: apartments.floor },
              { icon: <AttachMoney />, label: 'Цена', value: new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(apartments.totalPrice) },
            ].map((item, index) => (
              <Grid item xs={6} key={index}>
                <Box
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    p: 1.5,
                    border: '1px solid',
                    borderColor: 'rgba(255, 140, 0, 0.2)',
                    borderRadius: '8px',
                    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-3px)',
                      boxShadow: '0 5px 10px rgba(255, 140, 0, 0.1)',
                    },
                  }}
                >
                  <Box sx={{ color: '#FF8C00', mb: 1 }}>{item.icon}</Box>
                  <Typography variant="body2" color="text.secondary">
                    {item.label}
                  </Typography>
                  <Typography variant="body1" fontWeight="bold">
                    {item.value}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Paper>
      </Grid>
    </Grid>

    {/* Кнопки действий */}
    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 4 }}>
      <ShareButtons url={currentUrl} />
      <Box sx={{ display: 'flex', gap: 2 }}>
        {store.user.role !== 'ADMIN' && (
          <Button
            variant="contained"
            startIcon={<Home />}
            sx={{
              backgroundColor: '#FF8C00',
              color: 'white',
              borderRadius: '30px',
              px: 3,
              '&:hover': {
                backgroundColor: '#E67E00',
              },
            }}
            onClick={handleNavigate}
          >
            Забронировать просмотр
          </Button>
        )}
        <Button
          variant="outlined"
          sx={{
            color: '#FF8C00',
            borderColor: '#FF8C00',
            borderRadius: '30px',
            px: 3,
            '&:hover': {
              borderColor: '#E67E00',
              backgroundColor: 'rgba(255, 140, 0, 0.05)',
              color: '#E67E00',
            },
          }}
          onClick={handlePrint}
        >
          Печать
        </Button>
      </Box>
    </Box>
  </Box>
</Modal>
    </>
  );
};

export default ApartmentItem;

