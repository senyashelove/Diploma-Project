import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { reservAPI } from "../services/ReservService";
import { houseAPI } from '../services/houseService';
import { apartmentAPI } from "../services/ApartmentService";
import { userAPI } from "../services/UsrService";
import { postAPI } from "../services/PostService";

const rootReducer = combineReducers({
    [houseAPI.reducerPath]: houseAPI.reducer,
    [reservAPI.reducerPath]: reservAPI.reducer,
    [apartmentAPI.reducerPath]: apartmentAPI.reducer,
    [userAPI.reducerPath]: userAPI.reducer,
    [postAPI.reducerPath]: postAPI.reducer,
})

export const setupStore = () => {
    return configureStore({
        reducer: rootReducer,
        middleware: (getDefaultMiddleware) =>
            getDefaultMiddleware().concat(houseAPI.middleware, reservAPI.middleware, apartmentAPI.middleware, userAPI.middleware, postAPI.middleware)
    })
}
