import { makeAutoObservable } from "mobx";
import AuthService from "../services/AuthService";
import axios from "axios";
import { AuthResponse } from "../models/response/AuthResponse";
import { API_URL } from "../http";
import { User } from "../models/IUser";

export default class Store {
    constructor() {
        this.user = {};
        this.isAuth = false;
        makeAutoObservable(this);
    }

    setAuth(bool) {
        this.isAuth = bool;
    }

    setUser(user) {
        this.user = user;
    }

    async checkAuth() {
        try {
            const response = await axios.get(`${API_URL}/auth/refresh`, { withCredentials: true });
            localStorage.setItem('token', response.data.accessToken);
            this.setAuth(true);
            this.setUser(response.data.user);
        }
        catch (e) {
            console.log(e);
        }
    }
    async login(email, password) {
        try {
            const response = await AuthService.login(email, password);
            console.log(response);
            localStorage.setItem('token', response.data.accessToken);
            this.setAuth(true);
            this.setUser(response.data.user);
        }
        catch (e) {
            console.log(e);
        }
    }

    async update(data) {
        try {
            const response = await AuthService.update(data);
            console.log(response);
            this.setUser(response.data.user);
        }
        catch (e) {
            console.log(e);
        }
    }


    async registration(data) {
        try {
            const response = await AuthService.registration(data);
            console.log(response);
            localStorage.setItem('token', response.data.accessToken);
            this.setAuth(true);
            this.setUser(response.data.user);
            console.log('dsdsds');
            console.log(this.user);
        }
        catch (e) {
            console.log(e);
        }
    }

    async logout() {
        try {
            const response = await AuthService.logout();
            console.log(response);
            localStorage.removeItem('token');
            this.setAuth(false);
            this.setUser({});
        }
        catch (e) {
            console.log(e);
        }
    }

}
