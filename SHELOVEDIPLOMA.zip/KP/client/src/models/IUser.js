export class User {
    constructor(login, id, role) {
        this.login = login;
        this.id = id;
        this.role = role;
    }
}