import React, { useContext, useEffect, useState } from 'react';
import LoginForm from './components/LoginForm';
import { Context } from '.';
import { observer } from 'mobx-react-lite';
import UserService from './services/UserService';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Box from '@mui/material/Box';
import { Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import SignUp from './components/SingUpForm';
import ProfilePage from './components/ProfilePage';
import HouseContainer from './components/HouseContainer';
import Help from './components/help';
import HallManagement from './components/adminPanel';
import Button from '@mui/material/Button';
import PopupMessage from './components/Popupmessage';
import ApartmentContainer from './components/ApartmentContainer';
import Calculator from './components/Calculator';
import CloseIcon from '@mui/icons-material/Close';
import ReservationPage from './components/ReservationPage';
import ApartmentItem from './components/Apartmentitem';
import FavoritesList from './components/FavoritesList';
import PostFeed from './components/PostFeed';

const theme = createTheme({
  palette: {
    primary: {
      main: '#ff9900',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function App() {
  const { store } = useContext(Context);
  const [setUsers] = useState([]);
  const [isChatOpen, setIsChatOpen] = useState(false);

  useEffect(() => {
    if (localStorage.getItem('token')) {
      store.checkAuth();
    }
  }, []);

  async function getUsers() {
    try {
      const response = await UserService.fetchUsers();
      setUsers(response.data);
    } catch (e) {
      console.log(e);
    }
  }

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  return (
    <ThemeProvider theme={theme}>
      <Box>
        <Header></Header>
        <div>
          <PopupMessage />
        </div>
        <Routes>
          <Route exact path="/house" element={<HouseContainer />} />
          {!store.isAuth && (
            <>
              <Route path="/login" element={<LoginForm />} />
              <Route path="/singup" element={<SignUp />} />
            </>
          )}
          {store.user.role === 'ADMIN' && (
            <>
              <Route path="/admin" element={<HallManagement />} />
            </>
          )}
          {store.user.role === 'USER' && (
            <Route exact path="/" element={<HouseContainer />} />

          )}
          {store.isAuth && (
            <>
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/reservation" element={<ReservationPage />} />
              

            </>
          )}
          <Route path="/calculator" element={<Calculator />} />
          <Route path="/apartments" element={<ApartmentContainer />} />
          <Route path="/houses/:houseId/apartments" element={<ApartmentContainer />} />
          <Route path="*" element={<HouseContainer />} />
          <Route path="/favorites" element={<FavoritesList />} />
          <Route path="/posts" element={<PostFeed />} />
          <Route path="/posts" element={<PostFeed />} />

        </Routes>
        <>
          {isChatOpen && (
            <div style={{ position: 'fixed', bottom: '20px', right: '20px' }}>
              <Button
                variant="contained"
                sx={{
                  backgroundColor: 'rgb(19, 19, 19)',
                  color: 'white',
                  borderRadius: '50%',
                  padding: '10px',
                  minWidth: 'auto',
                  boxShadow: 3,
                  '&:hover': {
                    backgroundColor: 'rgb(19, 19, 19)',
                  },
                }}
                onClick={toggleChat}
              >
                <CloseIcon />
              </Button>
              <Help />
            </div>
          )}

          {!isChatOpen && (
            <div style={{ position: 'fixed', bottom: '20px', right: '20px' }}>
              {/* Кнопка открытия чата */}
              <Button
                variant="contained"
                sx={{
                  backgroundColor: 'rgb(19, 19, 19)',
                  color: 'white',
                  padding: '12px',
                  '&:hover': {
                    backgroundColor: 'rgb(19, 19, 19)',
                  },
                }}
                onClick={toggleChat}
              >
                Открыть чат
              </Button>
            </div>
          )}
        </>
      </Box>
    </ThemeProvider>
  );
}

export default observer(App);
