import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import axiosBaseQuery from '../http/axiosBaseQuery'


export const userAPI = createApi({
    reducerPath: 'usrAPI',
    baseQuery: axiosBaseQuery({ baseUrl: 'https://localhost:5000/users', }),
    endpoints: (build) => ({
        deleteUser: build.mutation({
            query: (id) => ({
                url: `/${id}`,
                method: 'DELETE'
            })
        }),
        getUsers: build.query({
            query: () => ({
                url: `/`,
                method: 'GET'
            })
        })
    })
})