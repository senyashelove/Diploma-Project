import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { createApi } from '@reduxjs/toolkit/query/react';
import axiosBaseQuery from '../http/axiosBaseQuery';

export const houseAPI = createApi({
  reducerPath: 'houseAPI',
  baseQuery: axiosBaseQuery({ baseUrl: 'https://localhost:5000/houses' }), // Базовый URL
  endpoints: (build) => ({
    fetchAllHouses: build.query({
      query: () => ({
        url: '/houses',
      }),
    }),
    getApartmentsByHouseId: build.query({
      query: (houseId) => ({
        url: `/${houseId}/apartments`,
        method: 'GET',
      }),
    }),
    createHouse: build.mutation({
      query: (house) => {
        const { newHouse, housePhoto } = house;
        const formData = new FormData();
        Object.entries(newHouse).forEach(([key, value]) => {
          formData.append(key, value);
        });
        formData.append('houseImage', housePhoto);
        return {
          url: '/create',
          method: 'POST',
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      },
    }),
    deleteHouse: build.mutation({
      query: (id) => ({
        url: `/delete/${id}`,
        method: 'DELETE',
      }),
    }),
    updateHouse: build.mutation({
      query: (house) => {
        const { editHouse, housePhoto } = house;
        const formData = new FormData();
        Object.entries(editHouse).forEach(([key, value]) => {
          formData.append(key, value);
        });
        formData.append('houseImage', housePhoto);
        return {
          url: '/update',
          method: 'PUT',
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      },
    }),
  }),
});
