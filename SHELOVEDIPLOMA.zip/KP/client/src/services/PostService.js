import { createApi } from '@reduxjs/toolkit/query/react';
import axiosBaseQuery from '../http/axiosBaseQuery';

export const postAPI = createApi({
  reducerPath: 'postAPI',
  baseQuery: axiosBaseQuery({ baseUrl: 'https://localhost:5000/posts' }),
  endpoints: (build) => ({
    getAllPosts: build.query({
      query: () => ({
        url: '/',
        method: 'GET',
      }),
    }),
    createPost: build.mutation({
      query: (post) => {
        const { newPost, postImage } = post;
        const formData = new FormData();
        formData.append('text', newPost.text);
        formData.append('postImage', postImage);

        return {
          url: '/add',
          method: 'POST',
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        };
      },
    }),
    updatePost: build.mutation({
      query: (post) => {
        const { id, updatedPost, postImage } = post;
        const formData = new FormData();
        formData.append('text', updatedPost.text);
        formData.append('postImage', postImage);

        return {
          url: `/${id}`,
          method: 'PUT',
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        };
      },
    }),
    deletePost: build.mutation({
      query: (id) => ({
        url: `/${id}`,
        method: 'DELETE',
      }),
    }),
  }),
});

export const {
  useGetAllPostsQuery,
  useCreatePostMutation,
  useUpdatePostMutation,
  useDeletePostMutation,
} = postAPI;
