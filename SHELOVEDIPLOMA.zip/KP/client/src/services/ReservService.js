import { createApi } from '@reduxjs/toolkit/query/react';
import axiosBaseQuery from '../http/axiosBaseQuery';
import { apartmentAPI } from './ApartmentService';

export const reservAPI = createApi({
  reducerPath: 'reservAPI',
  baseQuery: axiosBaseQuery({ baseUrl: 'https://localhost:5000/reservation' }),
  endpoints: (build) => ({
    createReservation: build.mutation({
      query: (reservation) => ({
        url: '/create',
        method: 'POST',
        data: reservation,
      }),
    }),
    getReservationsByUserId: build.query({
      query: (userId) => ({
        url: `/user/${userId}`,
        method: 'GET',
      }),
    }),
    getReservations: build.query({
      query: () => ({
        url: `/`,
        method: 'GET',
      }),
    }),
    getReservationsByDate: build.query({
      query: (data) => {
        console.log(data);
        return {
          url: `/date`,
          method: 'GET',
          params: { date: data.reservationDate, id: data.id },
        }
      },
    }),
    deleteReservation: build.mutation({
      query: (id) => ({
        url: `/delete/${id}`,
        method: 'DELETE',
      }),
    }),
  }),
});

export const {
  useCreateReservationMutation,
  useGetReservationsByUserIdQuery,
  useGetReservationsByDateQuery,
  useDeleteReservationMutation,
} = reservAPI;
