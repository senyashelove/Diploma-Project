import { createApi } from '@reduxjs/toolkit/query/react';
import axiosBaseQuery from '../http/axiosBaseQuery';

export const apartmentAPI = createApi({
    reducerPath: 'apartmentAPI',
    baseQuery: axiosBaseQuery({ baseUrl: 'https://localhost:5000/apartment' }),
    endpoints: (build) => ({
        getApartments: build.query({
            query: () => ({
                url: `/apartments`,
                method: 'GET',
            }),
        }),
        createApartment: build.mutation({
            query: (apartments) => {
                const { newApartment, apartmentImage } = apartments;
                const formData = new FormData();
                Object.entries(newApartment).forEach(([key, value]) => {
                    formData.append(key, value);
                });
                console.log(apartmentImage);
                formData.append('apartmentImage', apartmentImage);
                return {
                    url: `/create`,
                    method: 'POST',
                    data: formData,
                    headers: {
                        'Content-Type': 'multipart/form-data'
                      }
                }
            },
        }),
        deleteApartment: build.mutation({
            query: (id) => ({
                url: `/delete/${id}`,
                method: 'DELETE',
            }),
        }),
        soldApartment: build.mutation({
            query: (id) => ({
                url: `/sold/${id}`,
                method: 'PUT',
            }),
        }),
        updateApartment: build.mutation({
            query: (apartments) => {
                const { editApartment, apartmentImage } = apartments;
                const formData = new FormData();
                Object.entries(editApartment).forEach(([key, value]) => {
                    formData.append(key, value);
                });
                formData.append('apartmentImage', apartmentImage);
                return {
                    url: `/update`,
                    method: 'PUT',
                    data: formData,
                    headers: {
                        'Content-Type': 'multipart/form-data'
                      }
                }
            },
        }),
    }),
});

export const {
    useGetApartmentsQuery,
    useGetApartmentsByHouseIdQuery,
    useCreateApartmentMutation,
    useDeleteApartmentMutation,
    useUpdateApartmentMutation,
} = apartmentAPI;
