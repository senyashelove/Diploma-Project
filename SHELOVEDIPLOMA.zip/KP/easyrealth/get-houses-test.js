import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 100,             // количество одновременных пользователей
  duration: '30s',     // продолжительность теста
};

export default function () {
  const res = http.get('https://localhost:5000/houses/houses');


  check(res, {
    'статус 200': (r) => r.status === 200,
    'есть массив домов': (r) => {
      try {
        const data = JSON.parse(r.body);
        return Array.isArray(data);
      } catch (e) {
        return false;
      }
    },
  });

  sleep(1); // задержка между запросами
}
