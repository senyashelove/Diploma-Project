require('dotenv').config(); // Загружает переменные окружения из .env
const express = require("express");
const app = express();
const prisma = require('./models/prismaClient');
const https = require('https');
const fs = require('fs');
const userRouter = require("./routes/userRouter.js");
const authRouter = require("./routes/authRouter.js");
const reservRouter = require("./routes/reservRouter.js");
const cookieParser = require("cookie-parser");
const cors = require('cors');
const nodemailer = require('nodemailer');
const errorMiddleware = require('./middleware/errorMiddleware.js');
const axios = require('axios'); // Для работы с DeepAI API
const SavedApartmentRouter = require("./routes/savedApartments.js");
const postRouter = require('../easyrealth/routes/PostRouter.js');

app.use(cors({
    credentials: true,
    origin: process.env.CLIENT_URL
}));
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));



const test = require('./models/prismaClient.js');
const HouseRouter = require("./routes/HouseRouter.js");
const ApartmentsRouter = require("./routes/ApartmentsRouter.js");

app.use("/users", userRouter);
app.use("/reservation", reservRouter);
app.use('/auth', authRouter);
app.use('/houses', HouseRouter);
app.use('/apartment', ApartmentsRouter);
app.use('/favorites', SavedApartmentRouter);
app.use('/posts', postRouter);


app.post('/generate-image', async (req, res) => {
    const { prompt, output_format = "webp" } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
    }

    try {
        // Sending a request to DeepAI's text2img API
        const response = await axios.post(
            'https://api.deepai.org/api/text2img',
            {
                text: prompt, // The prompt for image generation
                output_format: output_format, // Image format (optional, defaults to png)
            },
            {
                headers: {
                    'api-key': 'ce67dd8e-ebe1-4b0c-9b00-e57c2e690b37'
                    , // Ensure you set this in your .env file
                    'Content-Type': 'application/json',
                }
            }
        );

        // Log the response
        console.log('Image generated successfully:', response.status);

        // Check if the API returned a valid image URL
        if (response.data && response.data.output_url) {
            res.json({
                message: 'Image generated successfully',
                imageUrl: response.data.output_url // The URL of the generated image
            });
        } else {
            res.status(500).json({ error: 'Failed to generate image' });
        }
    } catch (error) {
        console.error('Error generating image:', error.response?.data || error.message);
        res.status(500).json({ error: 'Failed to generate image. Try again later.' });
    }
});

app.use(function (req, res, next) {
    res.status(404).send("Not Found");
});

app.use(errorMiddleware);

const options = {
    key: fs.readFileSync("localhost-key.pem"),
    cert: fs.readFileSync("localhost.pem")
};

const server = https.createServer(options, app);

server.listen(5000, () => {
    console.log("Сервер запущен и ожидает подключения...");
});

