class UserDto {
    constructor(model) {
        this.id = model.id;
        this.surname = model.surname;
        this.name = model.name;
        this.email = model.email;
        this.role = model.role;
        this.tokens = model.tokens; // если вам нужно отображать токены
        this.reservations = model.reservations; // если вам нужно отображать бронирования
    }
}

module.exports = UserDto;
