const express = require("express");
const userController = require("../controllers/userController.js");
const userRouter = express.Router();
const authMiddleware = require('../middleware/authMiddleware.js');

userRouter.get("/", authMiddleware, userController.getUsers);
userRouter.delete("/:id", authMiddleware, userController.deleteUser);

module.exports = userRouter;