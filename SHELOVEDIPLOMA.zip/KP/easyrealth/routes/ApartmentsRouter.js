const express = require("express");
const ApartmentsRouter = express.Router();
const ApartmentsController = require("../controllers/ApartmentsController");
const multer = require('multer');
const upload = multer();

const imageUpload = upload.fields([
    { name: 'apartmentImage', maxCount: 1 },
]);

ApartmentsRouter.get('/apartments', ApartmentsController.getApartments);
ApartmentsRouter.post('/create', imageUpload, ApartmentsController.createApartment);
ApartmentsRouter.delete('/delete/:id', ApartmentsController.deleteApartment);
ApartmentsRouter.put('/sold/:id', ApartmentsController.soldApartment);
ApartmentsRouter.put('/update', imageUpload, ApartmentsController.updateApartment);

module.exports = ApartmentsRouter;
