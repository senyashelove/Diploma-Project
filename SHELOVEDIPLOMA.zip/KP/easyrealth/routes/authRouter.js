const express = require("express");
const authRouter = express.Router();
const controller = require("../controllers/authController.js");
const { check } = require('express-validator');
const authMiddleware = require("../middleware/authMiddleware.js");


authRouter.post('/registration', controller.registration);
authRouter.post('/login', controller.login);
authRouter.post('/logout', controller.logout);
authRouter.put('/update', authMiddleware, controller.update);
authRouter.get('/refresh', controller.refresh);
authRouter.get('/users', controller.getUsers);
authRouter.get('/user', controller.getUsers);
module.exports = authRouter;