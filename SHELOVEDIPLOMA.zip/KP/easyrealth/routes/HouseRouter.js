const express = require('express');
const HouseRouter = express.Router();
const controller = require('../controllers/HouseController');
const multer = require('multer');
const upload = multer();

const imageUpload = upload.fields([
    { name: 'houseImage', maxCount: 1 },
]);

HouseRouter.get('/houses', controller.getHouses);
HouseRouter.get('/houses/:id', controller.getHouseById);
HouseRouter.post('/create', imageUpload, controller.createHouse);
HouseRouter.delete('/delete/:id', controller.deleteHouse);
HouseRouter.put('/update', imageUpload, controller.updateHouse);
HouseRouter.get('/:houseId/apartments', controller.getApartmentsByHouseId);

module.exports = HouseRouter;
