const Router = require('express');
const router = new Router();
const SavedApartmentController = require('../controllers/SavedApartmentController');
const authMiddleware = require('../middleware/authMiddleware');

router.post('/add', authMiddleware, SavedApartmentController.addToFavorites);
router.delete('/:apartmentId', authMiddleware, SavedApartmentController.removeFromFavorites);
router.get('/', authMiddleware, SavedApartmentController.getFavorites);

module.exports = router;
