const express = require("express");
const reservRouter = express.Router();
const controller = require("../controllers/reservController");
const authMiddleware = require('../middleware/authMiddleware.js');

reservRouter.post('/create', authMiddleware, controller.createReservation);
reservRouter.get('/user/:userId', authMiddleware, controller.getReservationsByUserId);
reservRouter.get('/date', authMiddleware, controller.getReservationsByDate);
reservRouter.delete('/delete/:id', authMiddleware, controller.deleteReservation);
reservRouter.get('/', authMiddleware, controller.getReservations);


module.exports = reservRouter;
