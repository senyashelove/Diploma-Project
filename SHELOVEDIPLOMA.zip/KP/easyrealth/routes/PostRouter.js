const express = require("express");
const postRouter = express.Router();
const PostController = require('../controllers/PostController');
const multer = require('multer');
const upload = multer();

const imageUpload = upload.fields([
    { name: 'postImage', maxCount: 1 },
]);

postRouter.post('/add', imageUpload, PostController.createPost);
postRouter.put('/:id',  imageUpload, PostController.updatePost);
postRouter.get('/', PostController.getAllPosts);
postRouter.delete('/:id', PostController.deletePost);

module.exports = postRouter;
