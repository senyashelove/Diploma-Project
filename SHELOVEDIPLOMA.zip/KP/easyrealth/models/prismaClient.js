const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();


// const { UserService, userService } = require("../user-service");

class DBInstance {
    prisma;
    constructor() {
        this.prisma = prisma;
    }
}

module.exports = new DBInstance().prisma;
// module.exports = prisma;