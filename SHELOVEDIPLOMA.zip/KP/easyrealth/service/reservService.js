const tokenService = require('./tokenService');
require('dotenv').config();
const prisma = require('../models/prismaClient');
const bcrypt = require('bcryptjs');
const ApiError = require('../exceptions/error');
const nodemailer = require('nodemailer');
const AuthError = require('../exceptions/error');


const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'mr.arspro@gmail.com',
    pass: 'mcll qnjp urzo snsx'
  }
});

async function createReservation(data) {
  const currentTime = new Date(data.reservationDate);
  const time = new Date();
  const reserv = await prisma.reservation.findMany({
    where: {
      reservationDate: currentTime
    }
  });
  if(reserv.length > 0){
    throw AuthError.BadRequest('Время уже занято');
  }
  const reservation = await prisma.reservation.create({
    data: {
      userId: parseInt(data.userId),
      houseId: parseInt(data.houseId),
      apartmentsId: parseInt(data.apartmentsId),
      reservationDate: currentTime,
    },
  });

  return reservation;
}


async function getReservationsByUserId(userId) {
  const reservations = await prisma.reservation.findMany({
    where: {
      userId: parseInt(userId),
    },
    include: {
      house: true,
      apartments: true,
    },
  });
  return reservations;
}

async function getReservationsByDate(id, reservationDate) {
  const startOfDay = new Date(reservationDate);
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date(reservationDate);
  endOfDay.setHours(23, 59, 59, 999);

  const reservations = await prisma.reservation.findMany({
    where: {
      reservationDate: {
        gte: startOfDay,
        lte: endOfDay,
      },
      apartmentsId: parseInt(id),
    },
    include: {
      house: true,
      apartments: true,
    },
  });

  return reservations;
}

async function deleteReservation(id) {
  const reservations = await prisma.reservation.findUnique({
    where: {
      id: parseInt(id)
    },
    include: {
      user: true
    }
  });
  console.log(reservations);
  const mailOptions = {
    from: 'mr.arspro@gmail.com',
    to: reservations.user.email,
    subject: 'Покупка квартиры',
    text: 'Ваша запись на просмотр отменена'
  };
  await transporter.sendMail(mailOptions);
  const reservation = await prisma.reservation.delete({
    where: {
      id: parseInt(id),
    },
  });
  return reservation;
}

async function getReservations() {
  const reservations = await prisma.reservation.findMany();
  return reservations;
}

module.exports = {
  getReservations,
  createReservation,
  getReservationsByUserId,
  getReservationsByDate,
  deleteReservation,
};