const tokenService = require('./tokenService');
require('dotenv').config();
const prisma = require('../models/prismaClient');
const bcrypt = require('bcryptjs');
const ApiError = require('../exceptions/error');
const ImageService = require('./ImageService');
const nodemailer = require('nodemailer');


const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'mr.arspro@gmail.com',
        pass: 'mcll qnjp urzo snsx'
    }
});

class HouseService {
    // Получить все дома
    async getHouses() {
        const houses = await prisma.houses.findMany({
            include: {
                apartments: true,  // Включаем связанные квартиры для каждого дома
                reservations: true // Включаем связанные бронирования для каждого дома
            }
        });

        if (!houses) {
            throw ApiError.BadRequest('Данные не найдены');
        }
        console.log(houses);
        return houses;
    }

    // Получить дом по ID с связанными квартирами и бронированиями
    async getHouseById(id) {
        const house = await prisma.houses.findUnique({
            where: {
                id: parseInt(id)
            },
            include: {
                apartments: true,
                reservations: true
            }
        });

        if (!house) {
            throw ApiError.BadRequest('Дом не найден');
        }
        console.log(house);
        return house;
    }

    // Создать новый дом
    async createHouse(houseImage, data) {
        const image = await ImageService.uploadImage(houseImage);
        const house = await prisma.houses.create({
            data: {
                name: data.name,
                address: data.address,
                floors: parseInt(data.floors, 10),
                image: image,
            }
        });
        console.log(house);
        return house;
    }

    // Удалить дом по ID
    async deleteHouse(id) {
        const reserv = await prisma.reservation.findMany({
            where: {
                houseId: parseInt(id)
            }
        });
        if (reserv.length > 0) {
            reserv.forEach(async (r) => {
                const user = await prisma.users.findUnique({
                    where: {
                        id: parseInt(r.userId)
                    }
                });
                const mailOptions = {
                    from: 'mr.arspro@gmail.com',
                    to: user.email,
                    subject: 'Покупка квартиры',
                    text: 'Квартира, на которую у вас имеется бронирование, была удалена из системы. Ваша запись отменена'
                };
                await transporter.sendMail(mailOptions);
            });
        }
        const house = await prisma.houses.delete({
            where: {
                id: parseInt(id)
            }
        });
        return house;
    }

    // Обновить данные дома
    async updateHouse(houseImage, data) {
        const image = await ImageService.uploadImage(houseImage);
        const house = await prisma.houses.update({
            where: {
                id: parseInt(data.id),
            },
            data: {
                name: data.name,
                address: data.address,
                floors: parseInt(data.floors, 10),
                image: image,
            },
        });
        return house;
    }

    async updateHouseWithoutImage(data) {
        const house = await prisma.houses.update({
            where: {
                id: parseInt(data.id),
            },
            data: {
                name: data.name,
                address: data.address,
                floors: parseInt(data.floors, 10),
            },
        });
        return house;
    }

    async getApartmentsByHouseId(houseId) {
        const apartments = await prisma.apartments.findMany({
            where: {
                houseId: parseInt(houseId),
                isSold: false
            },
            include: {
                house: true
            }
        });
        console.log(apartments);
        return apartments;
    }
}

module.exports = new HouseService();