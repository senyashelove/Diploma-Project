const tokenService = require('./tokenService');
require('dotenv').config();
const prisma = require('../models/prismaClient');
const bcrypt = require('bcryptjs');
const ApiError = require('../exceptions/error');
const ImageService = require('./ImageService');
const nodemailer = require('nodemailer');


const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'mr.arspro@gmail.com',
        pass: 'mcll qnjp urzo snsx'
    }
});

class ApartmentsService {

    async getApartments() {
        const apartments = await prisma.apartments.findMany({});
        if (!apartments) {
            throw ApiError.BadRequest('Квартиры не найдены');
        }
        console.log(apartments);
        return apartments;
    }


    async createApartment(apartmentImage, data) {
        const image = await ImageService.uploadImage(apartmentImage);
        const apartments = await prisma.apartments.create({
            data: {
                floor: parseInt(data.floor),
                name: data.name,
                houseId: parseInt(data.houseId),
                rooms: parseInt(data.rooms),
                area: parseFloat(data.area),
                pricePerM2: parseFloat(data.pricePerM2),
                totalPrice: parseFloat(data.totalPrice),
                image: image,
                isSold: false,
            }
        });
        console.log(apartments);
        return apartments;
    }

    async soldApartment(id) {
        const reserv = await prisma.reservation.findMany({
            where: {
                apartmentsId: parseInt(id)
            }
        });
        if (reserv.length > 0) {
            reserv.forEach(async (r) => {
                const user = await prisma.users.findUnique({
                    where: {
                        id: parseInt(r.userId)
                    }
                });
                const mailOptions = {
                    from: 'mr.arspro@gmail.com',
                    to: user.email,
                    subject: 'Покупка квартиры',
                    text: 'Квартира, на которую у вас имеется бронирование, была куплена. Ваша запись отменена'
                };
                await transporter.sendMail(mailOptions);
                await prisma.reservation.delete({
                    where: {
                        id: parseInt(r.id)
                    }
                });
            });
        }
        const apartments = await prisma.apartments.update({
            where: {
                id: parseInt(id)
            },
            data: {
                isSold: true,
            }
        });
        return apartments;
    }

    async deleteApartment(id) {
        const reserv = await prisma.reservation.findMany({
            where: {
                apartmentsId: parseInt(id)
            }
        });
        if (reserv.length > 0) {
            reserv.forEach(async (r) => {
                const user = await prisma.users.findUnique({
                    where: {
                        id: parseInt(r.userId)
                    }
                });
                const mailOptions = {
                    from: 'mr.arspro@gmail.com',
                    to: user.email,
                    subject: 'Покупка квартиры',
                    text: 'Квартира, на которую у вас имеется бронирование, была удалена из системы. Ваша запись отменена'
                };
                await transporter.sendMail(mailOptions);
            });
        }
        const apartments = await prisma.apartments.delete({
            where: {
                id: parseInt(id)
            }
        });
        return apartments;
    }

    async updateApartment(data) {
        const apartments = await prisma.apartments.update({
            where: {
                id: parseInt(data.id)
            },
            data: {
                floor: parseInt(data.floor),
                houseId: parseInt(data.houseId),
                rooms: parseInt(data.rooms),
                area: parseFloat(data.area),
                pricePerM2: parseFloat(data.pricePerM2),
                totalPrice: parseFloat(data.totalPrice)
            }
        });
        console.log(apartments);
        return apartments;
    }

    async updateApartmentWithImage(apartmentImage, data) {
        const image = await ImageService.uploadImage(apartmentImage);
        const apartments = await prisma.apartments.update({
            where: {
                id: parseInt(data.id)
            },
            data: {
                floor: parseInt(data.floor),
                houseId: parseInt(data.houseId),
                rooms: parseInt(data.rooms),
                area: parseFloat(data.area),
                pricePerM2: parseFloat(data.pricePerM2),
                totalPrice: parseFloat(data.totalPrice),
                image: image
            }
        });
        console.log(apartments);
        return apartments;
    }
}

module.exports = new ApartmentsService();