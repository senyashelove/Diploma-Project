const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const ImageService = require('../service/ImageService'); 

class PostService {
  async createPost(imageFile, text) {
    const image = await ImageService.uploadImage(imageFile);

    return await prisma.post.create({
      data: {
        image,
        text,
      },
    });
  }

  async updatePost(id, imageFile, text) {
    let image;

    if (imageFile) {
      image = await ImageService.uploadImage(imageFile);
    }

    return await prisma.post.update({
      where: { id: parseInt(id) },
      data: {
        ...(image && { image }),
        ...(text && { text }),
      },
    });
  }

  async getAllPosts() {
    return await prisma.post.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async deletePost(id) {
    return await prisma.post.delete({
      where: { id: parseInt(id) },
    });
  }
}

module.exports = new PostService();
