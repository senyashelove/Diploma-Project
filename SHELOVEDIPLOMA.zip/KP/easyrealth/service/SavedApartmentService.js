const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

class SavedApartmentService {
    async addToFavorites(userId, apartmentId) {
        return await prisma.savedApartment.create({
            data: {
                userId,
                apartmentsId: apartmentId,
            },
        });
    }

    async removeFromFavorites(userId, apartmentId) {
        return await prisma.savedApartment.deleteMany({
            where: {
                userId,
                apartmentsId: apartmentId,
            },
        });
    }

    async getFavorites(userId) {
        return await prisma.savedApartment.findMany({
          where: { userId },
          include: {
            apartment: {
              include: {
                house: true // вот это обязательно!
              }
            },
          },
        });
      }
      
}

module.exports = new SavedApartmentService();
