const { v2: cloudinary } = require('cloudinary');
const ApiError = require('../exceptions/error');
require('dotenv').config();

cloudinary.config({ 
  cloud_name: 'du51xd8en', 
  api_key: '791348296438764', 
  api_secret: process.env.CLOUDINARY_SECRET 
});

class ImageService {
    async convertBufferToDataUrl(fileBuffer) {
        return `data:image/jpeg;base64,${fileBuffer.toString('base64')}`;
    }

    async uploadImage(fileBuffer) {
        try {
            const dataUrl = await this.convertBufferToDataUrl(fileBuffer);
            const result = await cloudinary.uploader.upload(dataUrl);
            return result.secure_url;
        } catch (error) {
            console.error('Cloudinary upload error:', error);
            throw new ApiError(500, 'Error uploading image to Cloudinary');
        }
    }
}

module.exports = new ImageService();
