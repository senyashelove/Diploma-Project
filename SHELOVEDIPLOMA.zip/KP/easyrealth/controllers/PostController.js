const PostService = require('../service/PostService');
const ApiError = require('../exceptions/error');

class PostController {
  async createPost(req, res, next) {
    try {
      const { postImage } = req.files;
      const { text } = req.body;
      const post = await PostService.createPost(postImage[0].buffer, text);
      return res.json(post);
    } catch (e) {
      next(e);
    }
  }

  async updatePost(req, res, next) {
    try {
      const { postImage } = req.files || {};
      const { text } = req.body;
      const { id } = req.params;
      const post = await PostService.updatePost(id, postImage?.[0]?.buffer, text);
      return res.json(post);
    } catch (e) {
      next(e);
    }
  }

  async getAllPosts(req, res, next) {
    try {
      const posts = await PostService.getAllPosts();
      return res.json(posts);
    } catch (e) {
      next(e);
    }
  }

  async deletePost(req, res, next) {
    try {
      const { id } = req.params;
      const post = await PostService.deletePost(id);
      return res.json(post);
    } catch (e) {
      next(e);
    }
  }
}

module.exports = new PostController();
