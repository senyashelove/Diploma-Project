const AuthService = require('../service/authService');
const { validationResult } = require('express-validator');
const ApiError = require('../exceptions/error');
const HouseService = require('../service/HouseService');

class HousesController {
    // Получить все дома
    async getHouses(req, res, next) {
        try {
            const houses = await HouseService.getHouses();
            return res.json(houses);
        } catch (e) {
            next(e);
        }
    }

    async getHouseById(req, res, next) {
        try {
            const id = req.params.id;
            const house = await HouseService.getHouseById(id);
            return res.json(house);
        } catch (e) {
            next(e);
        }
    }

    async createHouse(req, res, next) {
        try {
            const { houseImage } = req.files;
            const data = req.body;
            const house = await HouseService.createHouse(houseImage[0].buffer, data);
            console.log(house);
            return res.json(house);
        } catch (e) {
            next(e);
        }
    }

    // Удалить дом по ID
    async deleteHouse(req, res, next) {
        try {
            const id = req.params.id;
            const house = await HouseService.deleteHouse(id);
            console.log(house);
            return res.json(house);
        } catch (e) {
            next(e);
        }
    }

    // Обновить дом
    async updateHouse(req, res, next) {
        try {
            const data = req.body;
            const { houseImage } = req.files;
            let house = {}
            if (!houseImage) {
                house = await HouseService.updateHouseWithoutImage(data);
            }
            else {
                house = await HouseService.updateHouse(houseImage[0].buffer, data);
            }   
            console.log(house);
            return res.json(house);
        } catch (e) {
            next(e);
        }
    }
    async getApartmentsByHouseId(req, res, next) {
        try {
            const houseId = req.params.houseId;
            const apartments = await HouseService.getApartmentsByHouseId(houseId);
            const house = await HouseService.getHouseById(houseId);
            return res.json({apartments, house});
        } catch (e) {
            next(e);
        }
    }
}

module.exports = new HousesController();