const SavedApartmentService = require('../service/SavedApartmentService');
const ApiError = require('../exceptions/error');

class SavedApartmentController {

    async addToFavorites(req, res, next) {
        try {
            const { apartmentId } = req.body;
            const userId = req.user.id;

            const saved = await SavedApartmentService.addToFavorites(userId, apartmentId);
            return res.json(saved);
        } catch (e) {
            next(e);
        }
    }

    async removeFromFavorites(req, res, next) {
        try {
            const { apartmentId } = req.params;
            const userId = req.user.id;

            const removed = await SavedApartmentService.removeFromFavorites(userId, parseInt(apartmentId));
            return res.json(removed);
        } catch (e) {
            next(e);
        }
    }

    async getFavorites(req, res, next) {
        try {
            const userId = req.user.id;

            const favorites = await SavedApartmentService.getFavorites(userId);
            return res.json(favorites);
        } catch (e) {
            next(e);
        }
    }
}

module.exports = new SavedApartmentController();
