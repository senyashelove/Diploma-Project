const AuthService = require('../service/authService');
const { validationResult } = require('express-validator');
const ApiError = require('../exceptions/error');
const ApartmentsService = require('../service/ApartmentsService');
const HouseService = require('../service/HouseService');

class ApartmentsController {
    async getApartments(req, res, next) {
        try {
            const apartments = await ApartmentsService.getApartments();
            
            return res.json(apartments);
        } catch (e) {
            next(e);
        }
    }


    async createApartment(req, res, next) {
        try {
            const { apartmentImage } = req.files;
            const data = req.body;
            const apartments = await ApartmentsService.createApartment(apartmentImage[0].buffer, data);
            console.log(apartments);
            return res.json(apartments);
        } catch (e) {
            next(e);
        }
    }

    async deleteApartment(req, res, next) {
        try {
            const id = req.params.id;
            const apartments = await ApartmentsService.deleteApartment(id);
            console.log(apartments);
            return res.json(apartments);
        } catch (e) {
            next(e);
        }
    }

    async soldApartment(req, res, next) {
        try {
            const id = req.params.id;
            const apartments = await ApartmentsService.soldApartment(id);
            console.log(apartments);
            return res.json(apartments);
        } catch (e) {
            next(e);
        }
    }

    async updateApartment(req, res, next) {
        try {
            const { apartmentImage } = req.files;
            const data = req.body;
            let apartments = {};
            if (!apartmentImage) {
                apartments = await ApartmentsService.updateApartment(data);
            } else {
                apartments = await ApartmentsService.updateApartmentWithImage(apartmentImage[0].buffer, data);
            }
            console.log(apartments);
            return res.json(apartments);
        } catch (e) {
            next(e);
        }
    }
}

module.exports = new ApartmentsController();