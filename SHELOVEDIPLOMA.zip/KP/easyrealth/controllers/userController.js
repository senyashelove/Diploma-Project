
const prisma = require('../models/prismaClient');

exports.getUsers = async function (request, response) {
    const user = await prisma.users.findMany({})
    return response.json(user)
};

exports.deleteUser = async function (request, response){
    const id = request.params.id;
    const user = await prisma.users.delete({
        where: {
            id: parseInt(id)
        }
    });
    return response.json(user);
}

