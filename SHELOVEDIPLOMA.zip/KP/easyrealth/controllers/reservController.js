const AuthService = require('../service/authService');
const { validationResult } = require('express-validator');
const ApiError = require('../exceptions/error');
const ReservService = require('../service/reservService');

class ReservController {
    async getReservations(req, res, next) {
        try {
            const reservations = await ReservService.getReservations();
            return res.json(reservations);
        } catch (e) {
            next(e);
        }
    }

    async getReservationsByUserId(req, res, next) {
        try {
            const userId = req.params.userId;
            const reservations = await ReservService.getReservationsByUserId(userId);
            return res.json(reservations);
        } catch (e) {
            next(e);
        }
    }

    async getReservationsByDate(req, res, next) {
        try {
            const reservationDate = req.query.date;
            const id = req.query.id;
            console.log(reservationDate);
            if (reservationDate) {
                const reservations = await ReservService.getReservationsByDate(id, reservationDate);
                return res.json(reservations);
            }
            else {
                return res.json();
            }
        } catch (e) {
            next(e);
        }
    }

    async createReservation(req, res, next) {
        try {
            const data = req.body;
            const reservation = await ReservService.createReservation(data);
            console.log(reservation);
            return res.json(reservation);
        } catch (e) {
            next(e);
        }
    }

    async deleteReservation(req, res, next) {
        try {
            const id = req.params.id;
            const reservation = await ReservService.deleteReservation(id);
            console.log(reservation);
            return res.json(reservation);
        } catch (e) {
            next(e);
        }
    }
}

module.exports = new ReservController();