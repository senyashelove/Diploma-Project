const jwt = require('jsonwebtoken');
require('dotenv').config();
const ApiError = require('../exceptions/error');
const tokenService = require('../service/tokenService');

module.exports =  async function (req, res, next) {
    try {
        const authorizationHeader = req.headers.authorization;
        if (!authorizationHeader) {
            return next(ApiError.UnauthorizedError());
        }
        console.log(authorizationHeader);
        const userData =  tokenService.validateAccessToken(authorizationHeader);
        if (!userData) {
            return next(ApiError.UnauthorizedError());
        }
     console.log('sdsd');
        req.user = userData;
        next();
    } catch (e) {
        return next(ApiError.UnauthorizedError());
    }
};